ARM_001__repair_color_v2
Corrected revision: preserve original vertex colors on all surviving faces, remove only exact-zero area faces (ARM001 42, ARM003 96). Supersedes earlier repair with missing color attributes. Not a new model or material variant; ARM003 budget unresolved.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_001_CC0.zip
OriginalZIP SHA256 2cc42526049acdfd62926ce922ead0324381ee2e4a6a846c72266e7bdf008f96
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
