WS_014__repair
Removed128 strictly zero-area column triangles; all positive surface faces and UV retained. Topology revision, not a new model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_014_CC0.zip
OriginalZIP SHA256 304c445caded5578436386bebf564a6fd04dd734d294fbdafda882dce32a5fbf
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
