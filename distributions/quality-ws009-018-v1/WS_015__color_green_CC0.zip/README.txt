WS_015__color_green
Green upholstery mapped micrograin; original geometry and UV retained. Wood, metal and all other material parameters unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_015_CC0.zip
OriginalZIP SHA256 a2384bb196433613cbc90652ad490c9899e37ba0b2029b386e64301064c2a0ca
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
