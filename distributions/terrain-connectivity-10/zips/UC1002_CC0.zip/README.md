# UC1002 — Cave skylight

A real 0.8 m square roof opening above a dry cave: floor 0 m, ceiling 0.75 m, roof approximately 1 m.

2 m square, XY centered origin, Z up, metre units, base -0.98 m. Blender 5.2.2. Geometry and included display materials only: CC0-1.0. Images, code and assembled examples are not included or licensed by this package.

GLB and BLEND reimport and sampled connection checks passed. Collision, actual walking, navigation meshes, complete manifoldness and Blender 4.3.2 compatibility are untested. Water is an opaque thin display surface; depth colors are illustrative, not a simulation. This is a local-use candidate, not a certified globally unique design.
