# UC1001 — Shallow ford

A shallow submerged crossing: bed -0.04 m, water -0.01 m, channel ports 1.2 m wide and -0.19 m deep.

2 m square, XY centered origin, Z up, metre units, base -0.98 m. Blender 5.2.2. Geometry and included display materials only: CC0-1.0. Images, code and assembled examples are not included or licensed by this package.

GLB and BLEND reimport and sampled connection checks passed. Collision, actual walking, navigation meshes, complete manifoldness and Blender 4.3.2 compatibility are untested. Water is an opaque thin display surface; depth colors are illustrative, not a simulation. This is a local-use candidate, not a certified globally unique design.
