FW014__repair
Material repair of existing model; no new base shape or color variant.
Invalid albedo-as-normal connections removed. Albedo image bytes and original material parameters preserved; mesh normals used. Original geometry, transforms and UV retained. No replacement normal detail invented.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-forest-witch/FW014_CC0.zip
Original ZIP SHA256: 2d985939a736781b2de0e1b0ec5b58f04a13e924f8721b5babf00d1056af783d
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
