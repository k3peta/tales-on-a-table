FW020__repair
Material repair of existing model; no new base shape or color variant.
Invalid albedo-as-normal connections removed. Albedo image bytes and original material parameters preserved; mesh normals used. Original geometry, transforms and UV retained. No replacement normal detail invented.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-forest-witch/FW020_CC0.zip
Original ZIP SHA256: be9bce4c9ac9f524d303661be5475940ace65c2a83ffa2dcdc524b7b1797699a
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
