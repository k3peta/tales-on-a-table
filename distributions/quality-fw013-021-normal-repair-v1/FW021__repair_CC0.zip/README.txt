FW021__repair
Material repair of existing model; no new base shape or color variant.
Invalid albedo-as-normal connections removed. Albedo image bytes and original material parameters preserved; mesh normals used. Original geometry, transforms and UV retained. No replacement normal detail invented.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-forest-witch/FW021_CC0.zip
Original ZIP SHA256: a0b33f2b23a8263f7ad83a68ab41b2087bb79bac588ff0a29cccfd1db19e4381
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
