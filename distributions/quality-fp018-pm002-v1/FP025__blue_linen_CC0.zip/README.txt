FP025__blue_linen
Blue linen UV texture recolor based on repaired FP025 geometry; original wear luminance retained, alpha/normal/roughness/emission unchanged. Geometry same as repaired baseline, not unmodified original.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.20-prison/FP025_Folded_prison_uniform.zip
OriginalZIP SHA256 ef94147b664a06ef09d9d302f23e6534207613a4cb03ebb04459de40024d2b58
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
