TG023__repair
Distribution record TG023; contained model TG023. This is a single model revision of the existing record; no new design.
Geometry cleanup only: 8 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant. Exposed water tile edges retain an open planar-sheet appearance; no water volume or edge-closure repair.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG023_CC0.zip
SourceZIP SHA256 d7ee6896283dfab22cc54e358e920595b647c5102ecee56734fd2c254a6bdd64
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
