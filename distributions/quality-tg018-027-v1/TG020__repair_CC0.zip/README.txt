TG020__repair
Distribution record TG020; contained model TG020. This is a single model revision of the existing record; no new design.
Geometry cleanup only: 4 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant. Exposed water tile edges retain an open planar-sheet appearance; no water volume or edge-closure repair.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG020_CC0.zip
SourceZIP SHA256 519a1a2d1853cff853607fa5ab50df4fa854dbb67d270d1235a1a65565ec35c4
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
