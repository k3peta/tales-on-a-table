TG026__repair
Distribution record TG026; contained model TG026. This is a single model revision of the existing record; no new design.
Geometry cleanup only: 12 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant. Exposed water tile edges retain an open planar-sheet appearance; no water volume or edge-closure repair.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG026_CC0.zip
SourceZIP SHA256 09aa1771891d5d1ab4f7d895ccbc45a6d0f808a29e006f630d6a3c1e7c7b86a2
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
