FT_018__used
Material variant of FT_018; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_018_CC0.zip
Source ZIP SHA256 0b79e023e70929cc27bc5a748c4a109c5b7706e817692f0c709092ed0fa7244b
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
