FT_015__color
Material variant of FT_015; not a new base shape. Finish: natural alternate material colour; not a new shape
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_015_CC0.zip
Source ZIP SHA256 52c8d4c9d50e6c42a40e01f0a0e72bb94d48ba998b7af289de5370d883ea0aba
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
