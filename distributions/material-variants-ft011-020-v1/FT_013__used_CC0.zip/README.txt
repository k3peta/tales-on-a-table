FT_013__used
Material variant of FT_013; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_013_CC0.zip
Source ZIP SHA256 3a557003882812499debd4dc2993870694cb542f19c64fe5bfa0ca9d09e4778e
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
