FT_014__new
Material variant of FT_014; not a new base shape. Finish: maintained/new-like, retains original grain
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_014_CC0.zip
Source ZIP SHA256 638526583905ab70eef8a187cc4bb338d16f9fd0e3baa01e702ec3c9c870c00d
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
