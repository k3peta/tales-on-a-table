FT_017__new
Material variant of FT_017; not a new base shape. Finish: maintained/new-like, retains original grain
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_017_CC0.zip
Source ZIP SHA256 14bd4150053c91730d9cf72af5423543015e3bcb41c95a0528c0949424a48be1
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
