FT_016__used
Material variant of FT_016; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_016_CC0.zip
Source ZIP SHA256 3dc5ad1edc48a10856f6d7dcb2b9f05ba9416ef5146dd6fc9a5317fc5cfb69fc
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
