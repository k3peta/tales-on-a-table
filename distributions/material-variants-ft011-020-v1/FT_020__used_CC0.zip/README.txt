FT_020__used
Material variant of FT_020; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_020_CC0.zip
Source ZIP SHA256 0c760e3ee20a6cf4fd85647053ecfe39f3f58095691cce54b09ae543c7e9ecba
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
