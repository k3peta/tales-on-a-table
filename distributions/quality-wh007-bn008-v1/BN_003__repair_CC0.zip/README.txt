BN_003__repair
Missing UV added; geometry and original materials preserved.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-farmhouse-barn/BN_003_CC0.zip
OriginalZIP SHA256 0b42c76f7ba84398d44c2d973811fb156110768052b07f20606222c9a3ef1fd5
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
