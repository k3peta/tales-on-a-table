WH_NEW_008__repair
Exact-zero-face removal plus missing UV addition; positive surface and existing UV preserved.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/WH_NEW_008_CC0.zip
OriginalZIP SHA256 5984977a6b25b091a1ae461848226b053698bc96c31d664dab5fb9cc5cab6237
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
