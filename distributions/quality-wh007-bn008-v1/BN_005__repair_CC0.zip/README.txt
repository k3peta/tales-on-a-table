BN_005__repair
Missing UV added; geometry and original materials preserved.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-farmhouse-barn/BN_005_CC0.zip
OriginalZIP SHA256 087ade38a007f2bac69d6ce3afd9b247fc6f663955bf5d20d56e80869d157f18
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
