BN_006__bluewood
Blue wood pigment texture on original geometry and UV. Existing grain retained; normal, roughness and other channels unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-farmhouse-barn/BN_006_CC0.zip
OriginalZIP SHA256 dcdd1fdce8a85cd51bd34d0a14819e517b92bca455a6ca17d8825d17e6670ee3
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
