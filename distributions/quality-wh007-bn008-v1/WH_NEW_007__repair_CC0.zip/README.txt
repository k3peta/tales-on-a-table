WH_NEW_007__repair
Exact-zero-face removal plus missing UV addition; positive surface and existing UV preserved.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/WH_NEW_007_CC0.zip
OriginalZIP SHA256 a34f825509d0eb82feea89cb9c73d44eff0fe03a348791692ca104ae8256d3ca
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
