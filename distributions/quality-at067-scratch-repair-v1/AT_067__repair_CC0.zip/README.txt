AT_067__repair
Geometry repair of existing model; no new base shape or color variant.
42 detached body-scratch components replaced with thin surface ribbons within 0.2 mm of wooden surface. Scratch topology and UV changed; not original geometry invariant. Other wood, cut branches, hardware and grip retained. Open decorative surfaces intentional; not collision geometry. Small-prop polygon budget still exceeded.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_067_CC0.zip
Original ZIP SHA256: 65cf05e8752497e9254ced6b7de06e86c4212e56f88991771c570e23a3defe0b
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
