TD_011__repair
TD011 exact96 zero-area triangles removed; all positive surfaces retained. Budget remains exceeded. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-treasury-quality/TD_011_CC0.zip
OriginalZIP SHA256 25a684b9143c56385d438b93bf7b3172edbb991b467d0228b9d9554aa005c7d6
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
