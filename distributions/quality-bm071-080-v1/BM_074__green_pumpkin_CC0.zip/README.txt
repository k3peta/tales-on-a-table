BM_074__green_pumpkin
Vegetable surface color replaced by packed UV textures; original geometry, UV and attribute presence retained. Other material channels unchanged; no emission added. Stem and leaves retain original materials; no geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_074_CC0.zip
OriginalZIP SHA256 4e7ac5b4a4b87a4609de817e299b612e7ecf56da54ac2e3da78b5f24e6c39e2d
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
