BM_073__yellow_tomato
Vegetable surface color replaced by packed UV textures; original geometry, UV and attribute presence retained. Other material channels unchanged; no emission added. Stem and leaves retain original materials; no geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_073_CC0.zip
OriginalZIP SHA256 027a72a94e5ca05e92a73ada0b628c7b2131f4635e660bec565723ceb81a386a
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
