FTR101_StepoffLadder4m
structural_connection
Metres/Z-up; model root is ground0. Append Collection BLEND. Static models only; no climbing, mechanism, structural safety or4.3.2 compatibility tests. Ladder has15 rungs plus top platform at.25m intervals, step-off floorZ4 and handholdsZ4.8. Gate example places ladder(0,2.55,0),rotation180deg against existing access-v2 gate. Rod case contains three stored segments, no working fishing rig. Code and private records excluded.
