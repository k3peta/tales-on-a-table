FH_015__new
Type: material_variant of FH_015; not a new shape.
港灯の鉄部を手入れ後の材質へ。ガラス・灯火・真鍮は維持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_015_CC0.zip
Source ZIP SHA256: b4d80e653bbfe304a261a27344a9f0451f60e95988d13ba6f1c0b820cf903567
CC0 model and embedded materials only; private code, audit records and images excluded.
