FH_013__new
Type: material_variant of FH_013; not a new shape.
係留環の鉄部を手入れ後の鉄色に。石台は維持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_013_CC0.zip
Source ZIP SHA256: 09006871610540cd45db7133692787a10b5721bdbecf967d60e2957ae03e7219
CC0 model and embedded materials only; private code, audit records and images excluded.
