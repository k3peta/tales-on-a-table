FH_012__new
Type: material_variant of FH_012; not a new shape.
係船柱の鉄部を手入れ後の鉄色に。石台は維持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_012_CC0.zip
Source ZIP SHA256: 15bbafb2950e5690f02dc0ae6004d77cc8ca391fe16565c2578928725c305f2b
CC0 model and embedded materials only; private code, audit records and images excluded.
