FH_011__color
Type: material_variant of FH_011; not a new shape.
海側胸壁の暖かい砂色材質。原寸法・目地・形状を保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_011_CC0.zip
Source ZIP SHA256: 36ca9eb65b7ff1fd8a8c63f491603298c23b9e6914876c0fa0c68c877c37d305
CC0 model and embedded materials only; private code, audit records and images excluded.
