FH_017__repair
Type: revision of FH_017; not a new shape.
漁船内側の強い反復木目を低減し、肋材と座板の構造を読み取りやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_017_CC0.zip
Source ZIP SHA256: 0e7509766ae47c01835d95195fcd8706a2212725d9c8498f94f14599695b47a7
CC0 model and embedded materials only; private code, audit records and images excluded.
