FH_020__repair
Type: revision of FH_020; not a new shape.
あか汲みの大きな反復木目とUV継ぎ目のコントラストを抑えた材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_020_CC0.zip
Source ZIP SHA256: 0e81b01aafb95d6cd467459e380d0984d31c0b09fe548b9d050dd3bdbd2ef120
CC0 model and embedded materials only; private code, audit records and images excluded.
