ARM_022__bluehide
Shield hide basecolor chroma variant; original vertex color retained, UV tint texture multiplied. Geometry and UV unchanged. Roughness/normal/metallic/emission unchanged; not a geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_022_CC0.zip
OriginalZIP SHA256 51b47d175731c0fab2a4dd7cba6284c5457c888e1431cc81ee9c8cc4000dee29
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
