ARM_023__rusthide
Shield hide basecolor chroma variant; original vertex color retained, UV tint texture multiplied. Geometry and UV unchanged. Roughness/normal/metallic/emission unchanged; not a geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_023_CC0.zip
OriginalZIP SHA256 8ae4a0042eb086d915b81ca7256d5d92f5b303ef1c1a6dc4836d2a55651197c4
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
