ARM_021__repair
Exact-zero-area cleanup: ARM014 8 faces or ARM021 30 faces. All positive surfaces retained; ARM021 budget remains exceeded. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_021_CC0.zip
OriginalZIP SHA256 29defdeb3a18d3c783f590c98cfc5275401129666363df43a73df0b063dca68d
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
