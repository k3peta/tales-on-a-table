ARM_014__repair
Exact-zero-area cleanup: ARM014 8 faces or ARM021 30 faces. All positive surfaces retained; ARM021 budget remains exceeded. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_014_CC0.zip
OriginalZIP SHA256 e1dde319250155dd5cb2ef7766bce29d20781b172b2aa34b69da40fdc9b82cbe
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
