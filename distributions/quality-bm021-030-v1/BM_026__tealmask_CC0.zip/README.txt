BM_026__tealmask
Teal UV tint on ivory mask face; straps/red trim/brass and other channels unchanged. Original geometry, UV and vertex colors preserved. Not a new shape.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_026_CC0.zip
OriginalZIP SHA256 e3e954dd056c166c17a1dd762775571cdfb2843c224dacc5daafacdbe1a0f9a6
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
