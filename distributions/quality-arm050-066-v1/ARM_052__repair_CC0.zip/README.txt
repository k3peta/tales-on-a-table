ARM_052__repair
Exact-zero-area cleanup with positive surfaces, UV and vertex colors retained: ARM052 40 faces, ARM066 82 faces. ARM052 budget warning remains. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_052_CC0.zip
OriginalZIP SHA256 e1ea7e97fbcd78171650721f66cada4dc007bbbaa895d4967fb354c6498152e7
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
