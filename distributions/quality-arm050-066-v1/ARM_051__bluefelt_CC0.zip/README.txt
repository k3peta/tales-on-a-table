ARM_051__bluefelt
Blue or red felt UV tint multiplied with original vertex colors. Geometry/UV/roughness/normal/emission unchanged. Not a new model or geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_051_CC0.zip
OriginalZIP SHA256 636ff52ea65e0eebcd13df42db07a16c5332dd2704ddcbb78ea227b73a6198e9
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
