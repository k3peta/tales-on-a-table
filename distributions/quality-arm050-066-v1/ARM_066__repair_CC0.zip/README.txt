ARM_066__repair
Exact-zero-area cleanup with positive surfaces, UV and vertex colors retained: ARM052 40 faces, ARM066 82 faces. ARM052 budget warning remains. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_066_CC0.zip
OriginalZIP SHA256 a9bd1f1cb88857004b4dcfaad36d9213942ba57b0ae9ae5e2a4c6bf2da0e65cc
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
