ARM_053__redfelt
Blue or red felt UV tint multiplied with original vertex colors. Geometry/UV/roughness/normal/emission unchanged. Not a new model or geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_053_CC0.zip
OriginalZIP SHA256 dd667832b60b513e729bc33f6834489039d5900eff6eddcfb29f31857d7de9c4
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
