WS_038__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_038_CC0.zip
OriginalZIP SHA256 0b7a0fff4faa3b11bc0af6088fae78ee5cb119bfd45349586b621819fa21324b
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
