WS_036__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_036_CC0.zip
OriginalZIP SHA256 27d9e1d35191610ffafaeb009bbfdc4ce6a3601dae092ce6f563d84ec71b42ae
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
