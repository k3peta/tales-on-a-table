WS_031__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_031_CC0.zip
OriginalZIP SHA256 42fc87459c6ca5d90b7efe58549b6ad382fbb951e7ee1f75592f11d47f6db979
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
