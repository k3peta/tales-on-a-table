WS_029__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_029_CC0.zip
OriginalZIP SHA256 f6c5e797f9aac2efcd1e1e7e147904f6069a020403ad828da1d1a9804709e13d
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
