ARM_076__repair
Exact-zero-area cleanup preserving all positive surfaces, UV and vertex colors: ARM068 6 faces, ARM076 150 faces. ARM076 budget remains exceeded. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_076_CC0.zip
OriginalZIP SHA256 b9ce20f1a4a6a0ab38f51d19602562630d084ff9fd4cc8ce6faebcb15bd2e50c
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
