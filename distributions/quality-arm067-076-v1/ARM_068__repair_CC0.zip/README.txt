ARM_068__repair
Exact-zero-area cleanup preserving all positive surfaces, UV and vertex colors: ARM068 6 faces, ARM076 150 faces. ARM076 budget remains exceeded. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_068_CC0.zip
OriginalZIP SHA256 bfc7d2da27980aedd669f3de1ccf307c43df54b53b7c93cc0059688ede730e14
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
