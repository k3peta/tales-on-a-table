FP011__blue_glaze
Blue glaze UV texture recolor based on repaired FP011 geometry; original wear luminance retained, alpha/normal/roughness/emission unchanged. Geometry same as repaired baseline, not unmodified original.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.20-prison/FP011_Water_jug.zip
OriginalZIP SHA256 0fb11cfe90e9fab8be041b62c59119a0d82235e945952f80c8f481f5a0050257
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
