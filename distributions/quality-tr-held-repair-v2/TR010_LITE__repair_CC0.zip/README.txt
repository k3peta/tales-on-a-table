TR010_LITE__repair
Distribution record TR010; contained model TR010_LITE. HQ/LITE are versions of the same record, never separate new designs.
Original procedural bump baked to embedded2048px tangent-normal; original base-color textures unchanged. All original UV layers and baked atlas retained; UV0-copy padding added only where required to place baked atlas at UV2 uniformly. Duplicate wood definitions differing solely in normal UV index unified in model; verifier unchanged. Exact-zero faces removed: 2. Positive surfaces retained. Sampled bake fidelity/seams evaluated separately from attribute pass. Revision of existing model, not new base or variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-terrain-v2/TR010_CC0.zip
SourceZIP SHA256 7a95be1fdb0c05343961f089353c0a9d41a47e46cec210704e327ca570dbb482
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
