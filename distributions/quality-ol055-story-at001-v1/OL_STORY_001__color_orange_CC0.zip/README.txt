OL_STORY_001__color_orange
Type: material_variant of OL_STORY_001; not a new base shape.
手箱に掛けた布をオレンジへ。箱や配置は保持。配置作品の材質variant。
Original geometry, transforms and UV0 retained. Additional WearUV used for image mapping.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_STORY_001_CC0.zip
Source ZIP SHA256: 44f3b9158c245334f2b5efe6ae967e5b345f3cd87ff499246ae644c737279301
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
