OL_055__repair
Type: revision of OL_055; not a new base shape.
展示台の強い周期木目を抑制。原本形状・金属縁は保持。
Original geometry, transforms and UV0 retained. Additional WearUV used for image mapping.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_055_CC0.zip
Source ZIP SHA256: 3fd749bae65ccdd9f81713f22f526f984103af6d4af56125cbaf4d3e22f8e7e5
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
