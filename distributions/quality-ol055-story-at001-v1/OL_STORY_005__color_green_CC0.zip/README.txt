OL_STORY_005__color_green
Type: material_variant of OL_STORY_005; not a new base shape.
土産包みの布素材をグリーンへ。紙包みと縄は保持。配置作品の材質variant。
Original geometry, transforms and UV0 retained. Additional WearUV used for image mapping.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_STORY_005_CC0.zip
Source ZIP SHA256: 393f9e0e10f7d7f4ca773c07c0d397665ed81ffc11832267abd38e9ad52ea176
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
