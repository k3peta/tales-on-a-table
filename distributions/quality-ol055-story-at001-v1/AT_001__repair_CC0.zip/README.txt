AT_001__repair
Type: revision of AT_001; not a new base shape.
浮いて見えた水平目盛りの下へ真鍮の支持輪を追加した形状改訂。原本頂点不変更。
Original vertices and transforms retained. Added closed brass graduation support annulus: inner diameter 0.420 m, outer 0.454 m, z 0.421-0.4295 m, 768 triangles. Total 6068 triangles. This is a geometry revision, not an invariant-geometry material variant.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_001_CC0.zip
Source ZIP SHA256: 68be0df622a87ae6705f4af1cfb30ab207482049e9f49ece0defcc7c633b8476
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
