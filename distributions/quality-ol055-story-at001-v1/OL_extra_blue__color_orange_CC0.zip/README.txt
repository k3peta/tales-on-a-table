OL_extra_blue__color_orange
Type: material_variant of OL_extra_blue; not a new base shape.
青い単体クッションの布面をオレンジ系へ。形・縫目・飾りボタンを保持。
Original geometry, transforms and UV0 retained. Additional WearUV used for image mapping.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_extra_blue_CC0.zip
Source ZIP SHA256: 0daec767e5694bcb4a8377123692831ec2f117d3aec39261a39f4b05749f437f
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
