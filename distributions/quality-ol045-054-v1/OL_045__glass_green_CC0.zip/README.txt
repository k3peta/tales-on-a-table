OL_045__glass_green
Type: material_variant of OL_045; not a new shape.
三脚ランプの外装モザイクガラスをグリーン系へ。液体色ではない。原本透過/発光/目地/脚を保持。
Original mesh geometry and transforms retained; original UV0 retained. Additional WearUV is used for wood/metal mapping; exterior glass uses original UV only. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_045_CC0.zip
Source ZIP SHA256: 05760d5c246614030822c3596d1e0a98ff4a8a2e911957933ecc82d73c9ee333
CC0 model and embedded materials only; private code, audit records and images excluded.
