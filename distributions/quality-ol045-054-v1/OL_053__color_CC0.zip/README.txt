OL_053__color
Type: material_variant of OL_053; not a new shape.
鏡の金属枠を金色から銀色へ。鏡面と形状は保持。
Original mesh geometry and transforms retained; original UV0 retained. Additional WearUV is used for wood/metal mapping; exterior glass uses original UV only. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_053_CC0.zip
Source ZIP SHA256: 558f94db9693dd4826d90c2e33765dedc9fde89a503ac2839ad188f84b4353b9
CC0 model and embedded materials only; private code, audit records and images excluded.
