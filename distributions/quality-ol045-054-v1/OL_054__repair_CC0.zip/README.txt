OL_054__repair
Type: revision of OL_054; not a new shape.
鏡付き棚の強い周期木目を抑えた材質改訂。金具と鏡面を保持。
Original mesh geometry and transforms retained; original UV0 retained. Additional WearUV is used for wood/metal mapping; exterior glass uses original UV only. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_054_CC0.zip
Source ZIP SHA256: 19256135c8943540df27c913c07a74cddaa3e2803736d762a144467dbb41df56
CC0 model and embedded materials only; private code, audit records and images excluded.
