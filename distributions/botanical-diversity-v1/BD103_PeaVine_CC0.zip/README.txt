BD103_PeaVine
Paired leaflets, spiral tendrils, hanging seed pods. Vegetable garden; add separate supports as desired.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.5563299655914307, 0.560476154088974, 1.2526773961726576]. Root can extend below ground by up to 0.003m.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
