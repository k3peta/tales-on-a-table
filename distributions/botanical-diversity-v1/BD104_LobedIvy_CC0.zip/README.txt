BD104_LobedIvy
Five-lobed leaves on a vertical branching climber. Ruined wall dressing; front is -Y, wall plane +Y=0.025m. Not an automatic surface-conforming vine.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.8344354629516602, 0.03426138963550329, 1.1106768196914345]. Root can extend below ground by up to 0.003m.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
