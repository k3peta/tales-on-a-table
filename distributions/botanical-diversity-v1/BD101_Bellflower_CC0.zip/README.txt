BD101_Bellflower
Hollow five-lobed hanging bells on branching stems. Flower border.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.5446673929691315, 0.3391457796096802, 0.9394034329452552]. Root can extend below ground by up to 0.003m.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
