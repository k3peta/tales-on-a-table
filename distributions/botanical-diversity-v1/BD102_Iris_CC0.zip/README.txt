BD102_Iris
Sword-shaped basal leaves and alternating upright/falling petals. Garden border.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.4770906865596771, 0.393662691116333, 1.0502251076541143]. Root can extend below ground by up to 0.003m.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
