TR003_LITE__repair
Distribution record TR003; contained model TR003_LITE. HQ/LITE are versions of the same record, never separate new designs.
Original procedural bump baked to embedded2048px tangent-normal; original base-color textures unchanged. All original UV layers retained, one separate bake layer added (UV1 orUV2). Exact-zero faces removed: 1. Positive surfaces retained. Sampled bake fidelity/seams evaluated separately from attribute pass. Revision of existing model, not new base or variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-terrain-v2/TR003_CC0.zip
SourceZIP SHA256 692dac09853dcaf1edd8975e478296911dd5e459a0bb84d6944c7cbb738b9767
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
