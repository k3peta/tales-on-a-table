PA023__repair
Distribution record PA023; contained model PA023. HQ/LITE are versions of the same record, never separate new designs.
Original procedural color/bump baked to embedded1024px base-color and tangent-normal. All original UV layers retained, one separate bake layer added (UV1 orUV2). Exact-zero faces removed: 0. Positive surfaces retained. Sampled bake fidelity/seams evaluated separately from attribute pass. Revision of existing model, not new base or variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-painter-atelier/PA023_CC0.zip
SourceZIP SHA256 ab91eb8d40662d391df883f4700f98f3180bf6e96c09cbf941379db9f03ef2d5
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
