PA022__repair
Distribution record PA022; contained model PA022. HQ/LITE are versions of the same record, never separate new designs.
Original procedural color/bump baked to embedded1024px base-color and tangent-normal. All original UV layers retained, one separate bake layer added (UV1 orUV2). Exact-zero faces removed: 64. Positive surfaces retained. Sampled bake fidelity/seams evaluated separately from attribute pass. Revision of existing model, not new base or variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-painter-atelier/PA022_CC0.zip
SourceZIP SHA256 c54a1e650824922bdf405bdab9d4ae5e47677c208c74475dbd1c4147e05ba2bc
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
