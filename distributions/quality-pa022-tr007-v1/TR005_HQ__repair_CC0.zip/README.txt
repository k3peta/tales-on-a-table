TR005_HQ__repair
Distribution record TR005; contained model TR005_HQ. HQ/LITE are versions of the same record, never separate new designs.
Original procedural bump baked to embedded2048px tangent-normal; original base-color textures unchanged. All original UV layers retained, one separate bake layer added (UV1 orUV2). Exact-zero faces removed: 0. Positive surfaces retained. Sampled bake fidelity/seams evaluated separately from attribute pass. Revision of existing model, not new base or variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-terrain-v2/TR005_CC0.zip
SourceZIP SHA256 d8e594d3449c8d25e1ed2c310ea91f9d95224d2a37181b7e6c1719d3c30d4c91
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
