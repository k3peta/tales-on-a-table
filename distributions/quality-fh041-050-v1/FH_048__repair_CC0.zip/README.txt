FH_048__repair
Type: revision of FH_048; not a new shape.
滑車の木製頬板の木目を抑え、車輪と金具の判別を改善。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_048_CC0.zip
Source ZIP SHA256: 217b96eb253cd87f64c90b6f24c05404928c4559ddd14bf40f4cfdf0a17bdcb1
CC0 model and embedded materials only; private code, audit records and images excluded.
