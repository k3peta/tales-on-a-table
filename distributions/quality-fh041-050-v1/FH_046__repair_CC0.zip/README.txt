FH_046__repair
Type: revision of FH_046; not a new shape.
荷車の反復木目を抑え、床板・車輪・支柱の構成を明瞭化。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_046_CC0.zip
Source ZIP SHA256: 68ebff1f83318914bfd7545f34c8415f4f2b98bfe8eb262965c1d495e6b751e0
CC0 model and embedded materials only; private code, audit records and images excluded.
