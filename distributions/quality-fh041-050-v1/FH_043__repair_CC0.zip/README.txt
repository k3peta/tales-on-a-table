FH_043__repair
Type: revision of FH_043; not a new shape.
小祠の木目を抑え、内部の舟形装飾と供物皿を読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_043_CC0.zip
Source ZIP SHA256: d0b516121536f9c0d9508cddb9e576ffb525d865cb1e053544f05b1e3800c0cd
CC0 model and embedded materials only; private code, audit records and images excluded.
