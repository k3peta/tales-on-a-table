FH_050__repair
Type: revision of FH_050; not a new shape.
流木の反復木目を抑制。瓶のガラス材質と元形状は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_050_CC0.zip
Source ZIP SHA256: 6d0f0c726a60266cfd62a48a2299cfa8d0b3a231e13fb9c37a87eb877344c680
CC0 model and embedded materials only; private code, audit records and images excluded.
