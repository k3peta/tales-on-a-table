FH_049__repair
Type: revision of FH_049; not a new shape.
工具束の木槌の木目を抑え、工具の輪郭を読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_049_CC0.zip
Source ZIP SHA256: 764c86ec566217008bbbe2634b68fa8f20e0dbfd509110cc28704ccaea8de204
CC0 model and embedded materials only; private code, audit records and images excluded.
