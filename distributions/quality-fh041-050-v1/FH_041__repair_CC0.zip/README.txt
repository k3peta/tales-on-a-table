FH_041__repair
Type: revision of FH_041; not a new shape.
帰港札の掛け板の反復木目を抑え、札と魚の印を読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_041_CC0.zip
Source ZIP SHA256: 8dd44abd0e5226d64d9b817578db4a8f07dd644babee282d01060e114fdc9fd1
CC0 model and embedded materials only; private code, audit records and images excluded.
