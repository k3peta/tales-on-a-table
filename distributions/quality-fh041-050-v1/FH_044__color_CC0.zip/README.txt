FH_044__color
Type: material_variant of FH_044; not a new shape.
皿のみ赤茶色の陶器に変更。貝殻の形状と材質は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_044_CC0.zip
Source ZIP SHA256: 06dfdab6ae0f16466c8dbd93a3e15307e2a62ecdddaccf65ada4cd5c471c0391
CC0 model and embedded materials only; private code, audit records and images excluded.
