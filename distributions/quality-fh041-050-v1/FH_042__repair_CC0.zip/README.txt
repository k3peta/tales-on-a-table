FH_042__repair
Type: revision of FH_042; not a new shape.
単体帰港札の木目コントラストを抑え、魚の印と吊り穴の判別を改善。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_042_CC0.zip
Source ZIP SHA256: 770a7d5069356f88818ab7dba27362d85900bb59596482e3946a3188019ab304
CC0 model and embedded materials only; private code, audit records and images excluded.
