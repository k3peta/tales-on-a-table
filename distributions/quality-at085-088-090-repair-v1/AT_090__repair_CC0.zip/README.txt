AT_090__repair
Geometry repair of existing model; no new base shape or color variant.
Local geometry or shading repair. AT085: paper draped above box wall, topology and interpolated UV changed. AT088: bindings rotated with scrolls, imported custom normals replaced with flat face shading with baked transforms; topology/UV retained. AT090: middle packet bindings rebuilt and ink conformed to each paper stack, geometry changed; binding UV replaced. Not original geometry invariant; not physical knot or collision simulation.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_090_CC0.zip
Original ZIP SHA256: 9e1b1f1a6aad65c52a3db8248f07f0a29dcd4c21452f31cf1e2361c88ebba14c
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
