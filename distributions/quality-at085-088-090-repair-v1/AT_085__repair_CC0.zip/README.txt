AT_085__repair
Geometry repair of existing model; no new base shape or color variant.
Local geometry or shading repair. AT085: paper draped above box wall, topology and interpolated UV changed. AT088: bindings rotated with scrolls, imported custom normals replaced with flat face shading with baked transforms; topology/UV retained. AT090: middle packet bindings rebuilt and ink conformed to each paper stack, geometry changed; binding UV replaced. Not original geometry invariant; not physical knot or collision simulation.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_085_CC0.zip
Original ZIP SHA256: e6bcba16f8024d115f2ec9239db17a3bb6f032ab3b8b9bc67135e384f2f934ce
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
