AP010__cobalt_glaze
Recolor existing bowl glaze UV texture on repaired AP010 baseline. Honey/wood, alpha, roughness and other channels retained. No new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-apiary/AP010_CC0.zip
OriginalZIP SHA256 fa50ea8cecb9bb13bc3537167897864caa9b1c4097e0bf9a64cc51090907b669
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
