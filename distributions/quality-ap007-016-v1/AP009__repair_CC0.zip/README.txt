AP009__repair
Remove exact-zero world-area faces only; preserve all positive surfaces/materials/UV/colors. No new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-apiary/AP009_CC0.zip
OriginalZIP SHA256 2465bce38c0e27f314f04618d8ddb12c57d3e232fcd295129c759f01e42cb7ae
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
