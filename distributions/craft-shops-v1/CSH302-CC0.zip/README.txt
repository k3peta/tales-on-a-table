CSH302: Leatherworker half-moon head knife
Units: metres; Z up. Ground-centered origin. Dimensions XYZ: [0.20000000298023224, 0.04399999976158142, 0.22949999570846558].
BLEND is an object library: File > Append > Object > CSH302.
GLB can be imported normally. All required model data are embedded. No external textures.
Fine procedural bump is Blender-only. GLB retains base colors, roughness and geometry.
Static decorative model for vignettes, not a mechanically functional or safety-rated structure. No animation, animal simulation, collision or fluid behavior is provided. Not a standard terrain-port connector. Resize and position for your arrangement.
Tested with Blender 5.2.2 LTS: both formats reload, finite bounds, ground origin, no zero-area faces and no missing material slots. Older Blender versions, other viewers and application FPS are untested.
Only geometry and included materials are CC0-1.0. See LICENSE-CC0.txt.
