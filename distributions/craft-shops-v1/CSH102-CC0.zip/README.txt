CSH102: Cobbler sole-working stake on tripod
Units: metres; Z up. Ground-centered origin. Dimensions XYZ: [0.4520503878593445, 0.5193279385566711, 0.7073487043380737].
BLEND is an object library: File > Append > Object > CSH102.
GLB can be imported normally. All required model data are embedded. No external textures.
Fine procedural bump is Blender-only. GLB retains base colors, roughness and geometry.
Static decorative model for vignettes, not a mechanically functional or safety-rated structure. No animation, animal simulation, collision or fluid behavior is provided. Not a standard terrain-port connector. Resize and position for your arrangement.
Tested with Blender 5.2.2 LTS: both formats reload, finite bounds, ground origin, no zero-area faces and no missing material slots. Older Blender versions, other viewers and application FPS are untested.
Only geometry and included materials are CC0-1.0. See LICENSE-CC0.txt.
