cobbler - rearrangeable static vignette, revision 1
Open the BLEND directly in Blender 5.2.2 LTS. Parts remain separate objects.
Where present, collections 01_ROOF_remove_for_cutaway, 02_ENTRANCE_remove_for_cutaway and 03_NEAR_WALL_remove_for_cutaway are hidden in renders to reveal the interior. Restore render visibility for the exterior; toggle viewport visibility as desired.
The GLB contains geometry and embedded display materials, without the presentation camera or lights. Its nodes can be moved individually in a compatible editor; import behavior varies by application.
Blender source uses metres and Z up; GLB uses standard glTF axes. Scene placement origin is the original ground layout center, not an automatic connector.
Static models only: doors, wheels, presses and fluid behavior are not animated or simulated. Garments are static reused display models; hanger fit is checked only for this arrangement. Tools and fixtures are illustrative and not engineered for real construction. Procedural Blender micro-bump may differ in GLB.
No application, script, external texture, rendered preview or private handoff is included. App integration and performance are untested.
Model CC0 rights and arrangement rights differ; read SCENE-RIGHTS.txt and MODEL-LICENSES.json.
