WH_NEW_004__repair
Exact-zero-area cleanup retains all positive surfaces and source vertex colors where present. Missing UV explicitly added for WH meshes; positive-face existing UV retained. Not a new base; budget remains where documented.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/WH_NEW_004_CC0.zip
OriginalZIP SHA256 75cf4938d32e7abb0f86aa27ccd749352de1fbaeb2365d3085d6d71e14b1d48e
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
