WH_NEW_003__repair
Exact-zero-area cleanup retains all positive surfaces and source vertex colors where present. Missing UV explicitly added for WH meshes; positive-face existing UV retained. Not a new base; budget remains where documented.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/WH_NEW_003_CC0.zip
OriginalZIP SHA256 99a787da6cb142c920ce75c0caeb0960a180da53cbd824b3b25571e409da2e85
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
