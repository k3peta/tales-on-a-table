ARM_077__repair
Exact-zero-area cleanup retains all positive surfaces and source vertex colors where present. Missing UV explicitly added for WH meshes; positive-face existing UV retained. Not a new base; budget remains where documented.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_077_CC0.zip
OriginalZIP SHA256 06320331f1f55d428ffda7edfb452c546db90a8e3d59c4289b1b0e7e7bce30a7
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
