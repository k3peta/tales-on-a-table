ARM_079__repair
Exact-zero-area cleanup retains all positive surfaces and source vertex colors where present. Missing UV explicitly added for WH meshes; positive-face existing UV retained. Not a new base; budget remains where documented.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_079_CC0.zip
OriginalZIP SHA256 6cbadd7b0df22eeeb56c61d28e393816528df829eeaec524a821ecb28ac28549
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
