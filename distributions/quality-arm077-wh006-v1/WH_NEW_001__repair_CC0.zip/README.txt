WH_NEW_001__repair
Exact-zero-area cleanup retains all positive surfaces and source vertex colors where present. Missing UV explicitly added for WH meshes; positive-face existing UV retained. Not a new base; budget remains where documented.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/WH_NEW_001_CC0.zip
OriginalZIP SHA256 36bede419803df3c19abe91e4f0c20e653709943a37e3405dcad95e94bed0993
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
