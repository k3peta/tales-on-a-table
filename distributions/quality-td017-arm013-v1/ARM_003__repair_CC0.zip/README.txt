ARM_003__repair
Exact-zero-area cleanup: ARM001 42 faces or ARM003 96 faces. All positive surfaces retained; ARM003 remains over budget. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_003_CC0.zip
OriginalZIP SHA256 01b88360f1bbf1d25a8cb1f7b408d0934f202507e12fde5dfe4fe93015072e17
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
