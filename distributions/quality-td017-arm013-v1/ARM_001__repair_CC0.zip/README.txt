ARM_001__repair
Exact-zero-area cleanup: ARM001 42 faces or ARM003 96 faces. All positive surfaces retained; ARM003 remains over budget. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_001_CC0.zip
OriginalZIP SHA256 2cc42526049acdfd62926ce922ead0324381ee2e4a6a846c72266e7bdf008f96
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
