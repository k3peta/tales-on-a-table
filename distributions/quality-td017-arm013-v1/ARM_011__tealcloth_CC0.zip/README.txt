ARM_011__tealcloth
TD017 gem body or ARM011 pennant cloth basecolor texture only. Original geometry retained; TD017 UV added before color baseline. Other material channels unchanged. Not a liquid-color variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_011_CC0.zip
OriginalZIP SHA256 bfc6aed4cf5ba11868bc2c4073cf79cdd431ac0d7b13e9dd994efac5c8c3a172
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
