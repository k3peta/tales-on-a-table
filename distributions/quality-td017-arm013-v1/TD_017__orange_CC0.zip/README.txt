TD_017__orange
TD017 gem body or ARM011 pennant cloth basecolor texture only. Original geometry retained; TD017 UV added before color baseline. Other material channels unchanged. Not a liquid-color variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-treasury-quality/TD_017_CC0.zip
OriginalZIP SHA256 3ca334d8e4ae1c83df09cbc88e650f3cc95193fed9ff366756d519d569d12988
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
