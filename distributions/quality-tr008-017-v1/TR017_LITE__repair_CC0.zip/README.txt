TR017_LITE__repair
Distribution record TR017; contained model TR017_LITE. HQ/LITE are versions of the same record, never separate new designs.
Original procedural bump baked to embedded2048px tangent-normal; original base-color textures unchanged. All original UV layers retained, one separate bake layer added (UV1 orUV2). Exact-zero faces removed: 408. Positive surfaces retained. Sampled bake fidelity/seams evaluated separately from attribute pass. Revision of existing model, not new base or variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-terrain-v2/TR017_CC0.zip
SourceZIP SHA256 26611d7a4c2ac688d0720d08e665ffb4b936a55b11d20b1641698b531952b7b1
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
