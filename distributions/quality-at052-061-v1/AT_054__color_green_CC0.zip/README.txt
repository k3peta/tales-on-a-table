AT_054__color_green
Type: material_variant of AT_054; not a new base shape.
Cameo background: green; relief and frame retained.
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_054_CC0.zip
Source ZIP SHA256: ec2a287447bdfc488b0a15e8c31a9366f277066e816ea9fc65e63b2b85f85d31
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
