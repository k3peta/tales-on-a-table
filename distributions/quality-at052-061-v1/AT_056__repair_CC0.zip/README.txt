AT_056__repair
Type: revision of AT_056; not a new base shape.
Quill and complete nib translated into inkwell; geometry revision, not new base or variant.
Quill and complete nib components translated into inkwell mouth. Original topology and UV retained; bounds changed. Geometry revision, not a same-geometry variant. Three mouth-height section clearances measured; physical balance and continuous collision untested.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_056_CC0.zip
Source ZIP SHA256: 826e2ec2940da9314583e569c6c330ac93d5439f88bd64c311c5ca954d47d5b2
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
