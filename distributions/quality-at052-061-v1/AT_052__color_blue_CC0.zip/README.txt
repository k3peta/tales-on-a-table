AT_052__color_blue
Type: material_variant of AT_052; not a new base shape.
Ring stand textile: oxblood to clear blue; rings and gems retained.
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_052_CC0.zip
Source ZIP SHA256: 9023ef0b5fbf99b8d8877a9013a0fa811a9e435483c2d2e1d3cdec151b95e803
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
