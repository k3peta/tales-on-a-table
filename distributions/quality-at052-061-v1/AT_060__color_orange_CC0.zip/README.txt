AT_060__color_orange
Type: material_variant of AT_060; not a new base shape.
Bird head/wings: orange decorative finish instead of green patina color.
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_060_CC0.zip
Source ZIP SHA256: da745332c1b33b2b3d24666b8ae3b9b8ab9356d8257dfcac86b4fd33ae54e0d7
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
