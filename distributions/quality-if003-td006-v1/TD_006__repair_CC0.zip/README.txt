TD_006__repair
Exact-zero-area cleanup, all positive surfaces retained; missing UV added where recorded. IF006 also replaces excessive striped wood basecolor and lowers existing normal strength to0.08. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-treasury-quality/TD_006_CC0.zip
OriginalZIP SHA256 481f7ddee3a12048071b5a1cb369d63b08477adf2f7143ec8096c6185cc5080d
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
