IF_006__repair
Exact-zero-area cleanup, all positive surfaces retained; missing UV added where recorded. IF006 also replaces excessive striped wood basecolor and lowers existing normal strength to0.08. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-independent-furnishings/IF_006_CC0.zip
OriginalZIP SHA256 0fb08678cfd615e479f681c68f47112258b8ac3bfd0e0cc2c1d3e86c9407ed02
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
