TD_002__repair
Exact-zero-area cleanup, all positive surfaces retained; missing UV added where recorded. IF006 also replaces excessive striped wood basecolor and lowers existing normal strength to0.08. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-treasury-quality/TD_002_CC0.zip
OriginalZIP SHA256 833e8e2bc202988967425c4aeac34818b407159283d9e960bf0c19c87e3c2eba
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
