IF_004__orange_ceramic
Orange ceramic basecolor on IF004 cleaned geometry/UV baseline. Glass and flame unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-independent-furnishings/IF_004_CC0.zip
OriginalZIP SHA256 29fbf0d57af08d1001a346e3cd6d6d7d56b491a5762311f42d30aaa6c53cb61f
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
