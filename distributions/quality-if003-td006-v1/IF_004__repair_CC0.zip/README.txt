IF_004__repair
Exact-zero-area cleanup, all positive surfaces retained; missing UV added where recorded. IF006 also replaces excessive striped wood basecolor and lowers existing normal strength to0.08. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-independent-furnishings/IF_004_CC0.zip
OriginalZIP SHA256 29fbf0d57af08d1001a346e3cd6d6d7d56b491a5762311f42d30aaa6c53cb61f
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
