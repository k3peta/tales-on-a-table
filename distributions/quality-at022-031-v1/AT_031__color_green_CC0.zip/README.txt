AT_031__color_green
Type: material_variant of AT_031; not a new base shape.
縫い目修復後を基準に巻き袋の革を緑へ。工具・金具・形を保持。
48 stitches seated onto leather: inward Y10mm and Z-6mm, original topology/UV retained. Geometry revision baseline stitch_seating_v1; color_green preserves this repaired baseline.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_031_CC0.zip
Source ZIP SHA256: 2370726eb716b9687df91f99c2d0d262f7a0ce7a59bfcfad6c0a78c84a4d05df
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
