AT_031__repair
Type: revision of AT_031; not a new base shape.
48本の浮いた縫い目を内側10mm/下6mmへ移し袋面へ着座。
48 stitches seated onto leather: inward Y10mm and Z-6mm, original topology/UV retained. Geometry revision baseline stitch_seating_v1; color_green preserves this repaired baseline.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_031_CC0.zip
Source ZIP SHA256: 2370726eb716b9687df91f99c2d0d262f7a0ce7a59bfcfad6c0a78c84a4d05df
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
