AT_022__color_red
Type: material_variant of AT_022; not a new base shape.
魔導書の緑表紙を赤へ。紙・鎖・金具・宝石は保持。
Original geometry and UV0 retained; base-color texture only.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_022_CC0.zip
Source ZIP SHA256: 33c67650c6a0b46a07e9e75c2b7d70d1aa05ef176030e2c1433dada06ce627aa
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
