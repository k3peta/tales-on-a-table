RI102_SluiceDistributor
2x2m supported distributor. S(0,-1,1), N(0,1,1), E(1,0,1) bed ports, .6m wet width. Gate fixed raised, .39m gap beneath gate. No animated or hydraulic simulation.
Metres, Z up, origin zero. Blender5.2.2 LTS. Append named Collection. Bounds [[-1.0, -1.0, 0.0], [1.0, 1.0, 2.202500104904175]]
Static miniature. No water dynamics, mechanisms, game collision, actual walking or Blender4.3.2 compatibility tested. Sampled geometry tests only. Overlapping solids, not manifold union. Global historical shape independence unconfirmed.
