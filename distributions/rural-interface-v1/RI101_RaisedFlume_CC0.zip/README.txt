RI101_RaisedFlume
2m NS supported flume. Open ends y+-1, wet width .6m, bed Z1, side top1.3. Ground feet Z0.
Metres, Z up, origin zero. Blender5.2.2 LTS. Append named Collection. Bounds [[-0.3959999978542328, -1.0, 0.0], [0.3959999978542328, 1.0, 1.3000000715255737]]
Static miniature. No water dynamics, mechanisms, game collision, actual walking or Blender4.3.2 compatibility tested. Sampled geometry tests only. Overlapping solids, not manifold union. Global historical shape independence unconfirmed.
