RI103_DitchFence
2m fence bay across ditch. Bank origin Z0, post bottoms0; centre hanging slat bottom-.46m. Intended .5m deep ditch, .04m clearance. Fixed slats and hinge pins, no movement or collision test.
Metres, Z up, origin zero. Blender5.2.2 LTS. Append named Collection. Bounds [[-1.0, -0.07999999821186066, -0.4599999785423279], [1.0, 0.07999999821186066, 1.1200000047683716]]
Static miniature. No water dynamics, mechanisms, game collision, actual walking or Blender4.3.2 compatibility tested. Sampled geometry tests only. Overlapping solids, not manifold union. Global historical shape independence unconfirmed.
