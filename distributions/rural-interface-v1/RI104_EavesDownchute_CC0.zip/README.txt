RI104_EavesDownchute
Attachment module: NS gutter y-1..1 at bedZ2; chute y1..2 drops to bedZ1. Wet width.6m, walls.3m. Attach to eaves/wall; not ground-supported. Outlet (0,2,1) fits raised flume. Roof and wall not included.
Metres, Z up, origin zero. Blender5.2.2 LTS. Append named Collection. Bounds [[-0.5099999904632568, -1.0, 0.9200000166893005], [0.3799999952316284, 2.0, 2.3000001907348633]]
Static miniature. No water dynamics, mechanisms, game collision, actual walking or Blender4.3.2 compatibility tested. Sampled geometry tests only. Overlapping solids, not manifold union. Global historical shape independence unconfirmed.
