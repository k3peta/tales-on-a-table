OC015__amber_glass
Architectural glazing amber color on unchanged geometry/UV; transmission/IOR/roughness and structural materials preserved. No emission, liquid edit or optical portability guarantee.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-octagonal-conservatory/OC015_CC0.zip
OriginalZIP SHA256 438f11a7d3ef97f714797166cfbd18196d674e21b4e2c7235e8d9ea44787805a
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
