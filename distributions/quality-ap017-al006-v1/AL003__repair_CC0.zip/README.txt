AL003__repair
Remove exact-zero world-area faces only; preserve all positive surfaces/materials/UV/colors. No new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-alchemist/AL003_CC0.zip
OriginalZIP SHA256 bc33eafbcd75fb6abb78131de617984d4db154efcd8d8173bf614729da13126e
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
