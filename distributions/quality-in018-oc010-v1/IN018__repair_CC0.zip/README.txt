IN018__repair
Remove exact-zero world-area faces only; preserve all positive surfaces/materials/UV/colors. No new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-inn/IN018_CC0.zip
OriginalZIP SHA256 53aa6a5491f08f9fe969fac193b2c880652e16f039597f16e16cf185b883a988
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
