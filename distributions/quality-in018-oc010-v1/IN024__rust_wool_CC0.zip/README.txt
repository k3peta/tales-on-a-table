IN024__rust_wool
UV color variant with unchanged baseline geometry/UV; alpha, roughness and other materials preserved. No new base model or wear simulation.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-inn/IN024_CC0.zip
OriginalZIP SHA256 ab8248752f306e62cf3abd1af3e8c8fe81436a476bdb630f0de578bbdbff97a1
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
