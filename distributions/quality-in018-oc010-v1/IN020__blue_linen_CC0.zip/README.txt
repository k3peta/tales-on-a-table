IN020__blue_linen
UV color variant with unchanged baseline geometry/UV; alpha, roughness and other materials preserved. No new base model or wear simulation.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-inn/IN020_CC0.zip
OriginalZIP SHA256 699c1a33dcbaba55d73cc95376fdbe71a3029ec5208e28fd5b8facb65c3064cc
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
