AT_002__color_blue
Type: material_variant of AT_002; not a new base shape.
時計ケースの木部を青い塗装色へ。文字盤・針・金具は保持。
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_002_CC0.zip
Source ZIP SHA256: fc2c9ca4cd17425d34eeeeee678e78c14006dfb369e59dd64e260f87fba5f060
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
