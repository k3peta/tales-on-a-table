AT_004__repair
Type: revision of AT_004; not a new base shape.
宙に離れた焦点調節軸・輪・ラックを筒側へ移動した静的形状改訂。元の面数/UV/外形寸法保持。
Focus shaft, wheel and rack teeth translated by (0, 0.012, 0.070) m onto the tube. Original topology, UV and overall bounds retained. Geometry revision, not a same-geometry variant.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_004_CC0.zip
Source ZIP SHA256: 8e8d1776bb9a818ad47bbf3ebcb5bd7ee509161b49e3a9450ad409f5c9e89017
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
