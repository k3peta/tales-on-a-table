AT_008__color_green
Type: material_variant of AT_008; not a new base shape.
オルゴールの内張りのみ緑へ。箱・シリンダー・金具は保持。
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_008_CC0.zip
Source ZIP SHA256: aa10e1f5af43a154b0fc9ac21dd41d1097dbc1ad76adc725479a9fae168586e2
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
