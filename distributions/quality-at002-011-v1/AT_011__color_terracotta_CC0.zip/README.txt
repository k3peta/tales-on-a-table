AT_011__color_terracotta
Type: material_variant of AT_011; not a new base shape.
梟仮面の象牙色面をテラコッタ系へ。輪郭・目の穴・金具は保持。
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_011_CC0.zip
Source ZIP SHA256: aa7157edda29c7d900dac2894a6d547d6480c9821a83df8997ad3e898083da73
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
