BD301_StrawberryRunner
Trifoliate serrated leaves, berries and two daughter crowns connected by runners. Ground cover for field edges.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [1.0817225575447083, 0.6692016273736954, 0.19997441628947854]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
