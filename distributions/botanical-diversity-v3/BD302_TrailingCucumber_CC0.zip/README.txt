BD302_TrailingCucumber
Ground-trailing vine with broad angular leaves, tendrils, elongated fruit and small flowers. Vegetable bed.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [1.166913628578186, 0.80736243724823, 0.13430677354335785]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
