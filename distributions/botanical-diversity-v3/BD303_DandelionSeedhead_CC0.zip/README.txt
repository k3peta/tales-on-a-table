BD303_DandelionSeedhead
Deeply toothed basal rosette and spherical parachute seed heads. Field margins and neglected walls; static seeds.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.4763250797986984, 0.4708373695611954, 0.5918655344285071]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
