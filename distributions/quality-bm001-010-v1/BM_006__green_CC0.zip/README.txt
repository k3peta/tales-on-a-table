BM_006__green
Ceramic cup body UV tint (green) multiplied by preserved original vertex colors. Original geometry and UV unchanged. Dust/roughness/normal/metallic/emission unchanged. Main wizard_cup member only; existing dealer_cup remains in original source ZIP.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_006_CC0.zip
OriginalZIP SHA256 d1c89e2d678e15fb061f314e4df94ad53b4f59e0c1019c4ce0870c525e978554
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
