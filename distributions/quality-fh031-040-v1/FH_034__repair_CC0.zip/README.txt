FH_034__repair
Type: revision of FH_034; not a new shape.
補修板の反復木目を抑え、刻みと補修道具を読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_034_CC0.zip
Source ZIP SHA256: 03bd21787b624674cd11b5400783dfd18cc4413c5376dd6a6e15dc84bd1411e4
CC0 model and embedded materials only; private code, audit records and images excluded.
