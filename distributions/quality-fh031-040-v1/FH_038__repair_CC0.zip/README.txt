FH_038__repair
Type: revision of FH_038; not a new shape.
長靴の甲2メッシュに欠落していたUVを追加。元の色と形状を維持。
Original mesh geometry and transforms retained; UV0 supplied on 2 formerly unwrapped constant-color meshes; existing UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_038_CC0.zip
Source ZIP SHA256: 5329f5f8fdd70b1c92d14ce5ec416497722307ea37e4bc5f901f548e814c4898
CC0 model and embedded materials only; private code, audit records and images excluded.
