FH_040__repair
Type: revision of FH_040; not a new shape.
潮位板の木目を抑え、目盛りの視認性を改善。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_040_CC0.zip
Source ZIP SHA256: 8392810f1da2888b48dec2d7a16dd5773a0c071e06068bfff30e81f81ae1679d
CC0 model and embedded materials only; private code, audit records and images excluded.
