FH_037__color
Type: material_variant of FH_037; not a new shape.
外套の布だけを青灰色に変更。革縁・紐・形状は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_037_CC0.zip
Source ZIP SHA256: 6f6d37f32ef3c273fede1a25a0cb999974f57a442163b1031386cace7f165345
CC0 model and embedded materials only; private code, audit records and images excluded.
