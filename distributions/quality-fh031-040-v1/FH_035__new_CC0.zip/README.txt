FH_035__new
Type: material_variant of FH_035; not a new shape.
金具の錆を除いた新品表現。箱本体と布紐は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_035_CC0.zip
Source ZIP SHA256: 7278070efc97af55a10696c3348a1896a1f57e03f66a64e292ea4df3bfe58c8f
CC0 model and embedded materials only; private code, audit records and images excluded.
