FH_033__repair
Type: revision of FH_033; not a new shape.
腰掛けの反復木目を抑え、座板・貫・継ぎ目を読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_033_CC0.zip
Source ZIP SHA256: 64bccaeb031567426007e00880721b2e091e4e34365fa0d645558f526a7b84a2
CC0 model and embedded materials only; private code, audit records and images excluded.
