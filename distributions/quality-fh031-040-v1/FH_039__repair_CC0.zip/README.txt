FH_039__repair
Type: revision of FH_039; not a new shape.
灯火手入れ箱の木目を抑え、仕切りと道具の判別を改善。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_039_CC0.zip
Source ZIP SHA256: cc9a474a230a374148f2b6b2951fb837867d541a0c3b985b2ab745f71f7133ed
CC0 model and embedded materials only; private code, audit records and images excluded.
