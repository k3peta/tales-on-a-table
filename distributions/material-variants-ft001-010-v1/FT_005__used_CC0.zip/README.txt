FT_005__used
Material variant of FT_005; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_005_CC0.zip
Source ZIP SHA256 393ba7245dbd0e770f609005c855f10b533b4bfab9fbeb199e84343e208e81d9
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
