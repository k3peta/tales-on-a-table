FT_008__used
Material variant of FT_008; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_008_CC0.zip
Source ZIP SHA256 8d62ce1bfdc5e06684c820322f2263c9510e654db36a27bef13bc70fa37ca50b
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
