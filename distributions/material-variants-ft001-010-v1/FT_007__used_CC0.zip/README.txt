FT_007__used
Material variant of FT_007; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_007_CC0.zip
Source ZIP SHA256 ed844d4cf04e14b79e66d6f9c50b728e27b7b4eaaf5646ff4daae162d7a032e6
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
