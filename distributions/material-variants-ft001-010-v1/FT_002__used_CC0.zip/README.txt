FT_002__used
Material variant of FT_002; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_002_CC0.zip
Source ZIP SHA256 1984690722138c00d2f51aa3ac8dccbae022530d2bbd537dbc44b0bb4a2e5bf9
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
