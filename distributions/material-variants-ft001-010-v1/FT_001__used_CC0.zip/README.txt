FT_001__used
Material variant of FT_001; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_001_CC0.zip
Source ZIP SHA256 feea207fc601ff84a1252a787b01ed39d0fbe6f61cb00aac363a78930da8dc15
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
