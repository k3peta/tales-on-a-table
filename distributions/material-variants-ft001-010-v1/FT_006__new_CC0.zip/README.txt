FT_006__new
Material variant of FT_006; not a new base shape. Finish: maintained/new-like, retains original grain
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_006_CC0.zip
Source ZIP SHA256 3872afd5d185e83928c53956580fe175eb0394cc47c6c8a14665d25f595a6e37
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
