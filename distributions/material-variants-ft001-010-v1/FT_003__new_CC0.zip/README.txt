FT_003__new
Material variant of FT_003; not a new base shape. Finish: maintained/new-like, retains original grain
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_003_CC0.zip
Source ZIP SHA256 728d3c30105989435ffbc9613e4d0b1140c545e15853c0111b36d958a442dc92
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
