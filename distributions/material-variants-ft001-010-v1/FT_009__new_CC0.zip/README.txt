FT_009__new
Material variant of FT_009; not a new base shape. Finish: maintained/new-like, retains original grain
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_009_CC0.zip
Source ZIP SHA256 511a61f08d97158d0fd2b4ca1e0d61e817ec6061df86da64ba765f8444cdb992
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
