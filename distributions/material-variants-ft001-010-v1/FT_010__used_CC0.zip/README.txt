FT_010__used
Material variant of FT_010; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_010_CC0.zip
Source ZIP SHA256 98e3194650b7f4be249f31162c44719f0b0cfe9d1b787cccb7839e7564f75560
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
