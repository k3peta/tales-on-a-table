FT_004__used
Material variant of FT_004; not a new base shape. Finish: used, subdued desaturation and higher roughness
Original geometry, UV and transform retained. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_004_CC0.zip
Source ZIP SHA256 875d1afe922fdaf7d9cce53df6fb7d6e36e6d130ab78d22c4b60ade33cfd374c
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
