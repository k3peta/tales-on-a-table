BM_061__purple_cabbage
Vegetable surface color replaced by packed UV textures; original geometry, UV and attribute presence retained. Other material channels unchanged; no emission added. Cabbage remains35000tri above20k small-prop warning, not a geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_061_CC0.zip
OriginalZIP SHA256 b9e1e87c3909fe66056df2ac187a24cfa5affde48b4393680187825c350af673
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
