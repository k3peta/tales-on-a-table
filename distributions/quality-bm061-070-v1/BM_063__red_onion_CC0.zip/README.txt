BM_063__red_onion
Vegetable surface color replaced by packed UV textures; original geometry, UV and attribute presence retained. Other material channels unchanged; no emission added. Cabbage remains35000tri above20k small-prop warning, not a geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_063_CC0.zip
OriginalZIP SHA256 0560c8297097708c478511856feace24d5dd87f62341be33209bd5ff1e3b6cd7
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
