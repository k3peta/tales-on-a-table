WS_024__color_orange
Orange lampshade basecolor texture; original geometry/UV and other material properties retained; no added emission.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_024_CC0.zip
OriginalZIP SHA256 2501af6ad45911284c581e6af7b0a64df3c807ede7663a50685f9ba5d9db84d7
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
