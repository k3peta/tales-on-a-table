WS_019__repair
Strictly zero-area triangle cleanup only; all positive surfaces and UV retained. No new base. Original small-prop polygon budget still exceeded for WS019/020.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_019_CC0.zip
OriginalZIP SHA256 3c54abb30d9e5b1b8c7937e1053d2638c1b0f4d07e1b52e34a639e1709f69116
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
