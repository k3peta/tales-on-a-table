WS_023__repair
Strictly zero-area triangle cleanup only; all positive surfaces and UV retained. No new base. Original small-prop polygon budget still exceeded for WS019/020.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_023_CC0.zip
OriginalZIP SHA256 b1ed2f954861225a6f6f6bbbb3243c8ef6d29a750a44a99513b6324ba62c6b47
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
