WS_022__repair
Strictly zero-area triangle cleanup only; all positive surfaces and UV retained. No new base. Original small-prop polygon budget still exceeded for WS019/020.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_022_CC0.zip
OriginalZIP SHA256 5c92809f54ab0a1808d4d77a9bec30e5d22a46f2b537faa9e6bb3f178b3c9bdc
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
