BM_043__bluebag
Main robe/bag UV color tint only, original geometry/UV/vertex colors and other material channels preserved. Polygon budget remains exceeded.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_043_CC0.zip
OriginalZIP SHA256 ef7a402547961d8a51d490c80b4c9221411bdaf2887c61f6a03cfc3db86ecaa4
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
