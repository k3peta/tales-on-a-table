BM_041__repair
Static shank-to-helix connector added48tri; original mesh/UV/colors retained, overlapping assembly not watertight union; no functional strength guarantee.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_041_CC0.zip
OriginalZIP SHA256 f1166540edf0b6d5dcfad0e9986697289a42d3a7f2f894d4f3423e6613ab4977
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
