BM_042__rustred
Main robe/bag UV color tint only, original geometry/UV/vertex colors and other material channels preserved. Polygon budget remains exceeded.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_042_CC0.zip
OriginalZIP SHA256 fbacc46653cdfe809dea686e1d17213046220f1fd9cf673157b54e87c7bfb4f8
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
