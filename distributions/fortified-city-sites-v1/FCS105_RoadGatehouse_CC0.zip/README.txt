FCS105_RoadGatehouse
6m frontage, clear central cart arch,4m upper deck, twin roofed tower rooms; old2m gate arch different scale/program
Units metres, Z up. Single models use ground origin(0,0,0); scenes preserve object transforms. BLEND is a Collection library: Append the named collection. Bounds [[-3.200000047683716, -1.1749999523162842, 0.0], [3.200000047683716, 1.1749999523162842, 5.890000343322754]].
Static illustrative assets. Hoist and gates do not operate. Gate central upper floor4m has no access stair in this batch. No walking, collision, load/safety, historical authenticity or Blender4.3.2 compatibility verification. Code and private handoff files are not included.
