FCS102_TreadwheelHoist
Grounded frame, treadwheel, boom and hanging stone sling; loose pulley not complete hoist
Units metres, Z up. Single models use ground origin(0,0,0); scenes preserve object transforms. BLEND is a Collection library: Append the named collection. Bounds [[-1.215000033378601, -0.8000000715255737, 0.0], [2.413499593734741, 0.8000000715255737, 4.305678367614746]].
Static illustrative assets. Hoist and gates do not operate. Gate central upper floor4m has no access stair in this batch. No walking, collision, load/safety, historical authenticity or Blender4.3.2 compatibility verification. Code and private handoff files are not included.
