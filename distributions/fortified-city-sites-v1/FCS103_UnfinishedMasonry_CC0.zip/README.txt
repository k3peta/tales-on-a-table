FCS103_UnfinishedMasonry
2m masonry bay with stepped unlaid top and tooth end; old wall remains existing reference
Units metres, Z up. Single models use ground origin(0,0,0); scenes preserve object transforms. BLEND is a Collection library: Append the named collection. Bounds [[-1.0, -0.40000003576278687, 0.0], [1.0, 0.40000003576278687, 1.997499942779541]].
Static illustrative assets. Hoist and gates do not operate. Gate central upper floor4m has no access stair in this batch. No walking, collision, load/safety, historical authenticity or Blender4.3.2 compatibility verification. Code and private handoff files are not included.
