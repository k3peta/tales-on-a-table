FCS106_WatchKiosk
2m guard booth with open door/window, bench and pitched roof; not barn/wine facility
Units metres, Z up. Single models use ground origin(0,0,0); scenes preserve object transforms. BLEND is a Collection library: Append the named collection. Bounds [[-1.149999976158142, -1.149999976158142, 0.0], [1.149999976158142, 1.149999976158142, 3.190000057220459]].
Static illustrative assets. Hoist and gates do not operate. Gate central upper floor4m has no access stair in this batch. No walking, collision, load/safety, historical authenticity or Blender4.3.2 compatibility verification. Code and private handoff files are not included.
