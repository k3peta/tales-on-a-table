FCSV01_ConstructionSite
Repositionable assembly of current FCS parts and verified CC0 NR102/BD104/RS201 where used, plus original scene fixtures. Not an additional independent shape.
Units metres, Z up. Single models use ground origin(0,0,0); scenes preserve object transforms. BLEND is a Collection library: Append the named collection. Bounds [[-4.5, -3.5, -0.4399999976158142], [4.5, 3.5, 4.305678367614746]].
Static illustrative assets. Hoist and gates do not operate. Gate central upper floor4m has no access stair in this batch. No walking, collision, load/safety, historical authenticity or Blender4.3.2 compatibility verification. Code and private handoff files are not included.
