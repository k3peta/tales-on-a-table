FCS104_MasonsDressingBank
Stone dressing bank with ashlar block and wedges; generic workbench not newly counted independent
Units metres, Z up. Single models use ground origin(0,0,0); scenes preserve object transforms. BLEND is a Collection library: Append the named collection. Bounds [[-0.8999999761581421, -0.445000022649765, 0.0], [0.8999999761581421, 0.6600000262260437, 1.2999999523162842]].
Static illustrative assets. Hoist and gates do not operate. Gate central upper floor4m has no access stair in this batch. No walking, collision, load/safety, historical authenticity or Blender4.3.2 compatibility verification. Code and private handoff files are not included.
