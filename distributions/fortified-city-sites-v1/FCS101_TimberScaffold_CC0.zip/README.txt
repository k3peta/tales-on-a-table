FCS101_TimberScaffold
2m bay deckZ2 with integral ladder and guard rails; published ladder alone not a scaffold
Units metres, Z up. Single models use ground origin(0,0,0); scenes preserve object transforms. BLEND is a Collection library: Append the named collection. Bounds [[-1.059999942779541, -0.9792154431343079, 0.0], [1.059999942779541, 0.6000000238418579, 2.8600001335144043]].
Static illustrative assets. Hoist and gates do not operate. Gate central upper floor4m has no access stair in this batch. No walking, collision, load/safety, historical authenticity or Blender4.3.2 compatibility verification. Code and private handoff files are not included.
