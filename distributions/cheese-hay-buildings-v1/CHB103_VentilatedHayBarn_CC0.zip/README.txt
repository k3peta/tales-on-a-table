CHB103_VentilatedHayBarn
structural_building
Metres/Z-up, ground origin0. Append named Collection from BLEND. Roof and walls remain separate objects; hide Removable_* objects for cutaway. Cheese house floor.15, rack floors.4/1/1.6/2.2, dry-hay store floor.6 and loading ramp1.8m. Dry hay ventilation display, not sealed fermented silage silo. No hygiene, maturation climate, food safety, building safety, load, fire safety, game collision or4.3.2 validation. Models/materials only; code/private records excluded.
