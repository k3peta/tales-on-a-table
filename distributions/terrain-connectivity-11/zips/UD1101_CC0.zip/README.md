# UD1101 — Under-rim drain

Dry under-rim channel: floor -0.5 m, width 1.2 m, ceiling -0.15 m, rim top 0 m. Not a human passage.

2 m square, XY centered origin, Z up, metre units, base -0.98 m. Blender 5.2.2. Geometry and included display materials only: CC0-1.0. Images, code and assembled examples are not included or licensed by this package.

GLB and BLEND reimport and sampled connection checks passed. Collision, actual walking, navigation meshes, complete manifoldness and Blender 4.3.2 compatibility are untested. Water is an opaque thin display surface; depth colors are illustrative, not a simulation. This is a local-use candidate, not a certified globally unique design.
