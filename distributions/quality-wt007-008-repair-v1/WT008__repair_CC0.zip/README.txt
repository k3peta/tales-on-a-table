WT008__repair
Type: revision of WT008; not a new base shape.
Trim water solid to existing channel banks, removing coplanar overlapping black wedges at tile ends. Water level -0.01 m and 2 m tile preserved; outlet water width 1.188421 m matches both revised tiles.
Trim water solid to existing channel banks, removing coplanar overlapping black wedges at tile ends. Water level -0.01 m and 2 m tile preserved; outlet water width 1.188421 m matches both revised tiles. Geometry repair, not a material variant or new shape.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WT008_CC0.zip
Source ZIP SHA256: 3161937a8a2358681cca78c81f392156bbcbd9d836472ba37a45f30c223f4c46
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
