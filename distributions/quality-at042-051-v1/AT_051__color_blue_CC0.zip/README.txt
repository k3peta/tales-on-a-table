AT_051__color_blue
Type: material_variant of AT_051; not a new base shape.
宝石箱の赤系外装を青へ。螺鈿/金具/内装と形状UVは保持。
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_051_CC0.zip
Source ZIP SHA256: b7a55e25991b0360643bf3a8468f1150d50fae62a385e8536a2ecf8c8d61de83
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
