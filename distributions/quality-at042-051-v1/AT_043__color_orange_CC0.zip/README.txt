AT_043__color_orange
Type: material_variant of AT_043; not a new base shape.
青いアンフォラの陶器部分を橙へ。金具/装飾/形状UVは保持。
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_043_CC0.zip
Source ZIP SHA256: 1e7cb78e7ead5fe188f7997aa749a090f9730559d3cd44645cd51f26cee36880
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
