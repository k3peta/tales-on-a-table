TR068_HQ__repair
Distribution record TR068; contained model TR068_HQ. HQ/LITE are versions of the same record, never separate new designs.
Original procedural bump baked to embedded2048px tangent-normal; original base-color textures unchanged. All original UV layers and baked atlas retained; UV0-copy padding added only where required to place baked atlas at UV2 uniformly. Uniform normalUV2 prevents UV-index-dependent material duplication; strict verifier unchanged. Exact-zero faces removed: 0. Positive surfaces retained. Partial material repair: soil bump restored, fine rock grain attenuated versus source BLEND. Sampled bake fidelity/seams evaluated separately from attribute pass. Revision of existing model, not new base or variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-terrain-v2/TR068_CC0.zip
SourceZIP SHA256 20d3c185d00a4e1894fcb159bced7551fe95ce9caff502f9bd9774a9efc3228f
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
