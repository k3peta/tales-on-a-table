TG005__repair
Distribution record TG005; contained model TG005. HQ/LITE are versions of the same record, never separate new designs.
Geometry cleanup only: 16 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG005_CC0.zip
SourceZIP SHA256 327d0479b68f53de8a97f91b96179f13579ed7b56e76128ba766bd7d09b62e91
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
