TG007__repair
Distribution record TG007; contained model TG007. HQ/LITE are versions of the same record, never separate new designs.
Geometry cleanup only: 4 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG007_CC0.zip
SourceZIP SHA256 af6ec1c4082da7ecd01a6235c6dce21f12fc4030a4ef8bbe1848184aed4bbe0c
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
