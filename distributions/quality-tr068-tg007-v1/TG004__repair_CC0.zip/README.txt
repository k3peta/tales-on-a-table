TG004__repair
Distribution record TG004; contained model TG004. HQ/LITE are versions of the same record, never separate new designs.
Geometry cleanup only: 12 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG004_CC0.zip
SourceZIP SHA256 e62703d66cb8273b17cf81b7014490d7ef31c6d2633e14bd421c69ad702de7c2
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
