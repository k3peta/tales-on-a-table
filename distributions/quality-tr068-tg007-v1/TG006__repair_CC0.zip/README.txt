TG006__repair
Distribution record TG006; contained model TG006. HQ/LITE are versions of the same record, never separate new designs.
Geometry cleanup only: 32 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG006_CC0.zip
SourceZIP SHA256 046cfc8a05e492142cb7f21b7726492054c1e76c7c54a57f645cd882d3dafa98
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
