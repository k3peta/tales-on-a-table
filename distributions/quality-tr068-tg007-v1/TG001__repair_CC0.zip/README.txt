TG001__repair
Distribution record TG001; contained model TG001. HQ/LITE are versions of the same record, never separate new designs.
Geometry cleanup only: 4 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG001_CC0.zip
SourceZIP SHA256 210d1045e1779b4b346af0d0133c26f39ba3b9159b1b0ec7aefe2d1eec579bff
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
