TG003__repair
Distribution record TG003; contained model TG003. HQ/LITE are versions of the same record, never separate new designs.
Geometry cleanup only: 12 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG003_CC0.zip
SourceZIP SHA256 59aff36d0a8384776c7f7781ad682c888e50601eec76991797ce2779d7092c7f
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
