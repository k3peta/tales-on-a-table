TG002__repair
Distribution record TG002; contained model TG002. HQ/LITE are versions of the same record, never separate new designs.
Geometry cleanup only: 4 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG002_CC0.zip
SourceZIP SHA256 23d95d03f19214c5ace134bcca9a3df1c305230fa2c69b7ff4e266127266f99d
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
