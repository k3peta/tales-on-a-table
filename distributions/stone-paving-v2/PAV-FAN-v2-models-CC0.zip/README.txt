PAV-FAN - Fan paving - revision v2

Ivory, blue-grey and sandstone colors repeat in concentric courses. The curved pattern DOES NOT continue seamlessly across adjacent panels. Use as an accent panel.

Dimensions: 2 x 2 m. X/Y extents -1 to +1 m; Z up.
Origin: ground center. Bottom Z -0.10 m; stone tops approximately -0.002 to +0.003 m.
Surface overlay for gardens and plazas; not a terrain connectivity block.

GLB: import normally. Base colors, roughness and physical bevels are included.
BLEND: object-library file. In Blender use File > Append, open the Object folder and choose PAV-FAN. This file is not a ready-lit presentation scene.
Fine procedural stone bump is Blender-only and is not reproduced by GLB.
No external textures are required.

Checked with Blender 5.2.2 LTS: both formats reload, finite coordinates, correct bounds and origin, zero degenerate faces. Application integration, performance, collision behavior and older Blender versions have not been tested.

Models and included materials: CC0-1.0; see LICENSE-CC0.txt.
