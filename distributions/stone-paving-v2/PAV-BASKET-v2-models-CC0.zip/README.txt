PAV-BASKET - Basket weave - revision v2

Three stones form each group. Ivory and blue-grey groups alternate in a checkerboard, following their orientation. Repeat panels with the same orientation.

Dimensions: 2 x 2 m. X/Y extents -1 to +1 m; Z up.
Origin: ground center. Bottom Z -0.10 m; stone tops approximately -0.002 to +0.003 m.
Surface overlay for gardens and plazas; not a terrain connectivity block.

GLB: import normally. Base colors, roughness and physical bevels are included.
BLEND: object-library file. In Blender use File > Append, open the Object folder and choose PAV-BASKET. This file is not a ready-lit presentation scene.
Fine procedural stone bump is Blender-only and is not reproduced by GLB.
No external textures are required.

Checked with Blender 5.2.2 LTS: both formats reload, finite coordinates, correct bounds and origin, zero degenerate faces. Application integration, performance, collision behavior and older Blender versions have not been tested.

Models and included materials: CC0-1.0; see LICENSE-CC0.txt.
