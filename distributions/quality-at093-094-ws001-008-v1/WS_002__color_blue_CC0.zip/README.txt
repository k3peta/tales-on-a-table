WS_002__color_blue
Cover only changed to blue mapped micrograin, original geometry andUV retained.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_002_CC0.zip
OriginalZIP SHA256 a42e27d7a30b28c526caee68a47b6e60df3b42e2d01c94353346127db330da77
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
