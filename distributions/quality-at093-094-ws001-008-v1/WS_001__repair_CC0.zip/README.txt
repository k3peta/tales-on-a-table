WS_001__repair
Removed3720 strictly zero-area triangles from2 clasps; all positive-area faces and UV retained, including64 tiny positive faces. Topology revision, no new model. Polygon budget remains exceeded.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_001_CC0.zip
OriginalZIP SHA256 9ecd384cd9ab7fabdb6223de156498cb425febfc82500364c6b89053f7d109a4
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
