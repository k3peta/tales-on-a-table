WS_003__color_green
Upper cover changed to green mapped micrograin, original geometry andUV retained. Original20696 triangles exceeds20k small-prop warning; not repaired.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_003_CC0.zip
OriginalZIP SHA256 c86306965543be30af1f74f9b97969e22ad92b51732f0bd1f1cbd31ae94b28f1
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
