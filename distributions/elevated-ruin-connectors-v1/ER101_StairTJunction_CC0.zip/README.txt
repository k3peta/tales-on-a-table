ER101_StairTJunction
2x4m stair-top T junction. Low S interface (0,-2,0), first riser .125m; 8 treads .25m run/.125m rise. Top floor1m; W(-1,1,1), E(1,1,1), N(0,2,1). Stair tread width .9m. Landing underside .8m; not a human underpass.
Metres, Z up, origin zero. Append named Collection from BLEND. Blender5.2.2 LTS. Bounds: [[-1.027500033378601, -2.0100624561309814, 0.0], [1.027500033378601, 2.0274999141693115, 1.880000114440918]]
Static miniature module. Open ports require adjoining pieces or closures. Ray samples and dimensions checked, not full-body collision, gameplay, structural safety or Blender4.3.2 compatibility. Not a sealed manifold union. No global independent-shape count claimed.
