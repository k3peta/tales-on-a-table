ER102_RuinArchWalkway
2m EW upper walkway at Z3m over NS arch. Deck width1m, conservative guard clearance .955m. Lower opening width1.2m; spring1.6m, centre crown2.2m. E/W upper ports (+/-1,0,3). Upper and lower routes are separate. Broken stone crest remains below deck.
Metres, Z up, origin zero. Append named Collection from BLEND. Blender5.2.2 LTS. Bounds: [[-1.0, -0.5275000333786011, 0.0], [1.0, 0.5275000333786011, 3.880000114440918]]
Static miniature module. Open ports require adjoining pieces or closures. Ray samples and dimensions checked, not full-body collision, gameplay, structural safety or Blender4.3.2 compatibility. Not a sealed manifold union. No global independent-shape count claimed.
