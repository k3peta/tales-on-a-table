TR030_HQ__repair
Distribution record TR030; contained model TR030_HQ. HQ/LITE are versions of the same record, never separate new designs.
Original procedural bump baked to embedded2048px tangent-normal; original base-color textures unchanged. All original UV layers and baked atlas retained; UV0-copy padding added only where required to place baked atlas at UV2 uniformly. Uniform normalUV2 prevents UV-index-dependent material duplication; strict verifier unchanged. Exact-zero faces removed: 0. Positive surfaces retained. Partial material repair: soil bump restored, fine rock grain attenuated versus source BLEND. Sampled bake fidelity/seams evaluated separately from attribute pass. Revision of existing model, not new base or variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-terrain-v2/TR030_CC0.zip
SourceZIP SHA256 1da048e6f75b9e6926f20dc4bc54847e26beac34db2c0475835303ea4972f753
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
