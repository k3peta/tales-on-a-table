AL008__emerald_glass
Glass-shell UV color on repaired AL008 baseline; not liquid. Cork, transmission, IOR, alpha, roughness and other channels retained. No new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-alchemist/AL008_CC0.zip
OriginalZIP SHA256 a391259c6ce3e6b80f9f95dd298fc52e001672e67c27016b456c2920bc33026d
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
