IN007__blue_wool
Blue wool UV color; trim and roughness preserved. No new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-inn/IN007_CC0.zip
OriginalZIP SHA256 682f6812c30d068c73272998d3ff8a9e04f2225a293c4a312e4fb0f2de6c3757
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
