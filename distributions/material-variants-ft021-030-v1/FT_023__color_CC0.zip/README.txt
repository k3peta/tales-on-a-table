FT_023__color
Material variant of FT_023; not a new base shape. Finish: natural material colour alternative
Original geometry, UV0 and transform retained; WearUV atlas added for position-specific texture maps. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_023_CC0.zip
Source ZIP SHA256 43a0913284d0ef4ac2936da3f49f262bc842d4dc4541c43c54704d843362a8ed
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
