FT_022__color
Material variant of FT_022; not a new base shape. Finish: natural material colour alternative
Original geometry, UV0 and transform retained; WearUV atlas added for position-specific texture maps. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_022_CC0.zip
Source ZIP SHA256 450e501b16532cb446c51a8503a9b0de36c16d7a4892d173cccabc609a289485
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
