FT_028__color
Material variant of FT_028; not a new base shape. Finish: natural material colour alternative
Original geometry, UV0 and transform retained; WearUV atlas added for position-specific texture maps. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_028_CC0.zip
Source ZIP SHA256 21529d93bca9fbe4a7b8414e8a38bdd059fa6b5c4aa4b9faee449bb09d799fc7
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
