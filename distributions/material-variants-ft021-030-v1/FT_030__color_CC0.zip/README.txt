FT_030__color
Material variant of FT_030; not a new base shape. Finish: natural material colour alternative
Original geometry, UV0 and transform retained; WearUV atlas added for position-specific texture maps. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_030_CC0.zip
Source ZIP SHA256 93c2e5c06117698421f843e8da8bd0060fee7a9c74a795e2458498d3a01d324f
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
