FT_027__color
Material variant of FT_027; not a new base shape. Finish: natural material colour alternative
Original geometry, UV0 and transform retained; WearUV atlas added for position-specific texture maps. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_027_CC0.zip
Source ZIP SHA256 47d52d8dae9da4d28caa4d1c5e027809778c2cc4b40d8db2ac281034d214f767
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
