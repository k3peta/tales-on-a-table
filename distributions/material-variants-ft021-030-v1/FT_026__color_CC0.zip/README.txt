FT_026__color
Material variant of FT_026; not a new base shape. Finish: natural material colour alternative
Original geometry, UV0 and transform retained; WearUV atlas added for position-specific texture maps. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_026_CC0.zip
Source ZIP SHA256 68bfb64cf7109212f747f791673509a5ec1c69ff58f618650db8d370b8f68294
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
