FT_021__used
Material variant of FT_021; not a new base shape. Finish: spatial edge contact and lower-area wear
Original geometry, UV0 and transform retained; WearUV atlas added for position-specific texture maps. Static model; no game collision or Blender4.3.2 compatibility certification. Geometry roundtrip max error <=1e-5m tested, UV/triangle signature verified.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_021_CC0.zip
Source ZIP SHA256 fd4f65e25fed8627976369068230505c01940c296553ee6b317467ee48649bd9
CC0 model geometry and embedded material textures only. Private code, audit and render images are excluded.
