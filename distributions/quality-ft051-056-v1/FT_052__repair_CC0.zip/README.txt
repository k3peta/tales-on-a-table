FT_052__repair
木杯の過剰な木目と白反射を抑制。金具・割れ目は維持。
Type: revision; no new base shape.
Original geometry and UV0 preserved. WearUV added. Static ornamental model; no functional, drinking safety, physical collision or real walking guarantee. Blender 5.2.2 tested, 4.3.2 untested.
FT053 retains 11 very small positive-area triangles below 1e-12 square metres after GLB triangulation (one polygon before export); not a complete topology certification.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_052_CC0.zip
Source ZIP SHA256: ffe84095cc2363d173c172024107b80c2ad694ff93ebccd3628e3d9e8c77bdfd
CC0 covers models and embedded materials only. Private code, notes and images excluded.
