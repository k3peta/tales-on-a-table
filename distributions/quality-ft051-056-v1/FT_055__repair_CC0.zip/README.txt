FT_055__repair
盾の微小面を整理し、暗い木部のコントラストを緩和。形状改訂。
Type: revision; no new base shape.
Geometry was revised to reduce microscopic degenerate geometry; not identical to the original release. Color variant uses this revised geometry. WearUV added. Static ornamental model; no functional, drinking safety, physical collision or real walking guarantee. Blender 5.2.2 tested, 4.3.2 untested.
FT053 retains 11 very small positive-area triangles below 1e-12 square metres after GLB triangulation (one polygon before export); not a complete topology certification.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_055_CC0.zip
Source ZIP SHA256: a337f9358af421da3f8e33e5d5198bbecc041d761874876d5aee74a3a43ffc78
CC0 covers models and embedded materials only. Private code, notes and images excluded.
