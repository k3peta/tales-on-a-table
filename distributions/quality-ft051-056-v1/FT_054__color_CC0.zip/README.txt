FT_054__color
工具巻きの革を灰緑色へ。木柄・糸・金具は維持。
Type: material_variant; no new base shape.
Original geometry and UV0 preserved. WearUV added. Static ornamental model; no functional, drinking safety, physical collision or real walking guarantee. Blender 5.2.2 tested, 4.3.2 untested.
FT053 retains 11 very small positive-area triangles below 1e-12 square metres after GLB triangulation (one polygon before export); not a complete topology certification.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_054_CC0.zip
Source ZIP SHA256: c7600c189903c212fb7e3b9fa72a4907c9bab4997c43686b0e064088f161a96b
CC0 covers models and embedded materials only. Private code, notes and images excluded.
