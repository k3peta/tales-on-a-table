FT_053__repair
鍵の微小面を整理し、暗い金属アルベドを明瞭化。形状改訂。
Type: revision; no new base shape.
Geometry was revised to reduce microscopic degenerate geometry; not identical to the original release. Color variant uses this revised geometry. WearUV added. Static ornamental model; no functional, drinking safety, physical collision or real walking guarantee. Blender 5.2.2 tested, 4.3.2 untested.
FT053 retains 11 very small positive-area triangles below 1e-12 square metres after GLB triangulation (one polygon before export); not a complete topology certification.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_053_CC0.zip
Source ZIP SHA256: e9f316340b53b6243a35cead65ea47a31c995643e7334828f809630c51f6d2a9
CC0 covers models and embedded materials only. Private code, notes and images excluded.
