FT_051__color
帳簿の革表紙をくすんだ緑へ。金具・紙・補修布は維持。
Type: material_variant; no new base shape.
Original geometry and UV0 preserved. WearUV added. Static ornamental model; no functional, drinking safety, physical collision or real walking guarantee. Blender 5.2.2 tested, 4.3.2 untested.
FT053 retains 11 very small positive-area triangles below 1e-12 square metres after GLB triangulation (one polygon before export); not a complete topology certification.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_051_CC0.zip
Source ZIP SHA256: 45e7f9494f14feb56e07461a9c9cca4d4e8e66931bd19900025d8102a6a85a4a
CC0 covers models and embedded materials only. Private code, notes and images excluded.
