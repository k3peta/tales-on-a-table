FT_055__color
整理済み盾形状を基準とする青灰色木部。旧原本との幾何一致は主張しない。
Type: material_variant; no new base shape.
Geometry was revised to reduce microscopic degenerate geometry; not identical to the original release. Color variant uses this revised geometry. WearUV added. Static ornamental model; no functional, drinking safety, physical collision or real walking guarantee. Blender 5.2.2 tested, 4.3.2 untested.
FT053 retains 11 very small positive-area triangles below 1e-12 square metres after GLB triangulation (one polygon before export); not a complete topology certification.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_055_CC0.zip
Source ZIP SHA256: a337f9358af421da3f8e33e5d5198bbecc041d761874876d5aee74a3a43ffc78
CC0 covers models and embedded materials only. Private code, notes and images excluded.
