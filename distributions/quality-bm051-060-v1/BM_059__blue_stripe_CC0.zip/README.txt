BM_059__blue_stripe
Awning colored stripe base color replaced by packed UV texture; geometry, UV and original attribute presence retained. Ivory stripes, wood and other material channels unchanged. No emission added.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_059_CC0.zip
OriginalZIP SHA256 d2a90fae8b5247d2edaae25afe28b68a877d4fe538e8e8368dbbcf3bc06cdb3c
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
