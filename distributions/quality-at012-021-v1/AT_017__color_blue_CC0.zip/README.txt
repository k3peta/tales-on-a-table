AT_017__color_blue
Type: material_variant of AT_017; not a new base shape.
盾の赤い地色を青へ。傷・紋章・金具・形状は保持。
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_017_CC0.zip
Source ZIP SHA256: 1c50883df7636b575231932aeff8d580c0b696782457ed6b66b0014d30a883b0
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
