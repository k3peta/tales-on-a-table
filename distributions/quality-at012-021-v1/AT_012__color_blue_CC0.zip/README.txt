AT_012__color_blue
Type: material_variant of AT_012; not a new base shape.
渡鴉仮面の革面を青へ。ガラスレンズ・金具・展示台は保持。
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_012_CC0.zip
Source ZIP SHA256: bf35dc8a3a9698e849b1f48cf772804a9b5960fa2f10c62081515a1a51370eee
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
