AT_020__color_copper
Type: material_variant of AT_020; not a new base shape.
竜の卵の緑系表面を銅色系へ。鱗・台座・支えは保持。材質光学パラメータは変更しない。
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_020_CC0.zip
Source ZIP SHA256: 1f086b72611e87be44388f9659bcdd4157940614647c2be21114cdad8d4551ae
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
