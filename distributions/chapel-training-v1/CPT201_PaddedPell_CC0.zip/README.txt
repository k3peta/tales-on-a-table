CPT201_PaddedPell
Static padded post with head/arms, not a working training device.
Metres, Z-up in Blender. Append Collection BLEND; scene furnishings remain repositionable. Bounds: [[-0.5249999761581421, -0.42500001192092896, 0.0], [0.5249999761581421, 0.42500001192092896, 1.7200000286102295]]
Static art: no structural safety, active mechanisms, collision/real walking, historical accuracy or4.3.2 compatibility validation. Model geometry and embedded materials CC0 only; code/images/private records excluded.
