CPTV02_TrainingCourt
Training court using existing target, practice sword, shield stand and bench; clear central area. Static presentation, no martial technique instructions.
Metres, Z-up in Blender. Append Collection BLEND; scene furnishings remain repositionable. Bounds: [[-4.0, -4.0, -0.23999999463558197], [4.0, 4.0, 2.0999999046325684]]
Static art: no structural safety, active mechanisms, collision/real walking, historical accuracy or4.3.2 compatibility validation. Model geometry and embedded materials CC0 only; code/images/private records excluded.
