CPT101_ChapelShell
Small6x8m chapel shell, floorZ.16, 1.68m entrance gap, separate roof/front/side objects for cutaway view. Coloured opaque panes; no simulated stained-glass lighting.
Metres, Z-up in Blender. Append Collection BLEND; scene furnishings remain repositionable. Bounds: [[-3.3499999046325684, -4.809999942779541, 0.0], [3.3499999046325684, 4.349999904632568, 6.590000152587891]]
Static art: no structural safety, active mechanisms, collision/real walking, historical accuracy or4.3.2 compatibility validation. Model geometry and embedded materials CC0 only; code/images/private records excluded.
