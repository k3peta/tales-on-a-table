CPT103_PrayerKneeler
Prayer kneeler, knee cushionZ.32m, elbow railZ.94m.
Metres, Z-up in Blender. Append Collection BLEND; scene furnishings remain repositionable. Bounds: [[-0.75, -0.375, 0.0], [0.75, 0.375, 0.9399999976158142]]
Static art: no structural safety, active mechanisms, collision/real walking, historical accuracy or4.3.2 compatibility validation. Model geometry and embedded materials CC0 only; code/images/private records excluded.
