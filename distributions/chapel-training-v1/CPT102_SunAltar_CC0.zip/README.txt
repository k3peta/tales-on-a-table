CPT102_SunAltar
Composite altar with sun backboard; topZ1.06m.
Metres, Z-up in Blender. Append Collection BLEND; scene furnishings remain repositionable. Bounds: [[-1.100000023841858, -0.5249999761581421, 0.0], [1.100000023841858, 0.5249999761581421, 2.059999942779541]]
Static art: no structural safety, active mechanisms, collision/real walking, historical accuracy or4.3.2 compatibility validation. Model geometry and embedded materials CC0 only; code/images/private records excluded.
