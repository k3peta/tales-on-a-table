AL023__repair
Remove exact-zero world-area faces only; preserve all positive surfaces/materials/UV/colors. No new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-alchemist/AL023_CC0.zip
OriginalZIP SHA256 8201cba91e39247619e1dcbefcd9a131b812686b3552a6645e94c9a1aa6b86da
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
