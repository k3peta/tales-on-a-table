AL020__blue_ceramic
Ceramic UV color on repaired AL020 baseline; roughness and other channels retained. No heat/material safety claim. No new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-alchemist/AL020_CC0.zip
OriginalZIP SHA256 a1869eaa3a4a85ea154c433fd3040165c9a12bb29f942d60eb3b6d86d59a4b98
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
