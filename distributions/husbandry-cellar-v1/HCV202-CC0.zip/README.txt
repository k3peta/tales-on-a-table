HCV202: Raised livestock stone water trough
Units: metres; Z up. Ground-centered origin. Dimensions XYZ: [1.7000000476837158, 0.8500000238418579, 0.7300000190734863].
BLEND is an object library: File > Append > Object > HCV202.
GLB can be imported normally. All required model data are embedded. No external textures.
Fine procedural bump is Blender-only. GLB retains base colors, roughness and geometry.
Static decorative model for vignettes, not a mechanically functional or safety-rated structure. No animation, animal simulation, collision or fluid behavior is provided. Not a standard terrain-port connector. Resize and position for your arrangement.
Tested with Blender 5.2.2 LTS: both formats reload, finite bounds, ground origin, no zero-area faces and no missing material slots. Older Blender versions, other viewers and application FPS are untested.
Only geometry and included materials are CC0-1.0. See LICENSE-CC0.txt.
