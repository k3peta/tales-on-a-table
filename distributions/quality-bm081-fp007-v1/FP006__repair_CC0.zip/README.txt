FP006__repair
Remove whole straw components that intersect blanket/pillow faces; retained geometry/UV/materials/corner normals preserved, other objects unchanged. Static edge-intersection test, not exhaustive collision validation.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.20-prison/FP006_Straw_sleeping_pallet.zip
OriginalZIP SHA256 0cf16e0ea4b32d243d550460ca9fb44b1a541291eec1b39e488256e47e7ea250
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
