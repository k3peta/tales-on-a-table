BM_083__blue_canvas
Blue valance canvas packed UV texture, original geometry/UV/material channels unchanged. No emission added.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_083_CC0.zip
OriginalZIP SHA256 819c38520684231fc75766e0d036d89ff327d7dffabefb13ed006dc5e5f15406
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
