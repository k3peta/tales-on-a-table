FW016__repair
Remove exact-zero world-area faces only; preserve all positive surfaces/materials/UV/colors. No new base model.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/quality-fw013-021-normal-repair-v1/FW016__repair_CC0.zip
OriginalZIP SHA256 de450030bb53b8d238cefa2a83a2352592894c2a9788ff331797e62772c76732
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
