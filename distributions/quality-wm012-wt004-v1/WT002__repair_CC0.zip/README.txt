WT002__repair
Remove exact-zero surface faces and add missing UV; all positive-area source triangles, materials and existing UV retained.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WT002_CC0.zip
OriginalZIP SHA256 226d0cafef2e09aa1798be01a2e71e954aa9131374a04bbba5bc0edf60010d2d
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
