WT004__repair
Remove exact-zero surface faces and add missing UV; all positive-area source triangles, materials and existing UV retained.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WT004_CC0.zip
OriginalZIP SHA256 54304a77e91f1778d450bb86be8e211bad6b146b4b2acf1700f9247e1fd6b444
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
