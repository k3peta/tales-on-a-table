WM014__repair
Add missing UV only; geometry/materials/existing UV unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM014_CC0.zip
OriginalZIP SHA256 04be1105e8144509c59ad8aa44956470271fd588ab09a6b9b36b8348bd21e896
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
