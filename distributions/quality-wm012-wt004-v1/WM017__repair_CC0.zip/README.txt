WM017__repair
Add missing UV only; geometry/materials/existing UV unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM017_CC0.zip
OriginalZIP SHA256 ece039adbd38f241bdf227c09c4bbe48b68eb2aad87a6a82918c8ca4d766afb6
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
