WM016__repair
Add missing UV only; geometry/materials/existing UV unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM016_CC0.zip
OriginalZIP SHA256 8694d155e9f6c87241b9a780221f69e6a7ad5fa7d4c91a4eafc24770f12d7107
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
