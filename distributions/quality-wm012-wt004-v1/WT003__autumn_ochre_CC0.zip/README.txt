WT003__autumn_ochre
Autumn ochre leaf UV color texture on repaired WT003 baseline; geometry/UV retained against repaired baseline. Not a new base model.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WT003_CC0.zip
OriginalZIP SHA256 797af9c6c09dd5cd671e1550cff812f909b9bef130660726ab1b762150146f42
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
