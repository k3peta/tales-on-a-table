WT001__repair
Remove exact-zero surface faces and add missing UV; all positive-area source triangles, materials and existing UV retained.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WT001_CC0.zip
OriginalZIP SHA256 3579a63bebf86d1d958accf8ea7ec57614ff6a510d2dd05542a73bd0362ea362
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
