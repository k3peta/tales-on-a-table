WM015__repair
Add missing UV only; geometry/materials/existing UV unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM015_CC0.zip
OriginalZIP SHA256 f06f677515760c87ce58b173b82292217923758dc585a568080839656549f88b
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
