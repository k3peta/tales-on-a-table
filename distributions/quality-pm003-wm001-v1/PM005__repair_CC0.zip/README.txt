PM005__repair
Add missing UV0 only on PM005_Mortar_Core. Original geometry/materials and existing UV layers retained. UV-only revision, no new base or palette variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.20-prison/PM005_Arched_Window_Wall_2m.zip
OriginalZIP SHA256 84bc2f7864adeedd2bfcc085fb6e010a0ad81dcd7b2884801f2a13cfcbd979de
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
