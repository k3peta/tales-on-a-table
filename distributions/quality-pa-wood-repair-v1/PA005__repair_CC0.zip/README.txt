PA005__repair
Original source-BLEND procedural wood baked to embedded 1024px base-color and tangent-normal textures. Original UV0 retained, nonoverlapping UV1 added. Existing exact-zero cleanup retained where applicable. Material/UV repair, not a new base or color variant. Visual seam and source-appearance validation recorded separately.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-painter-atelier/PA005_CC0.zip
OriginalZIP SHA256 f60ca2c990ade8f123dacf5ebb9dbad58216d9d24abfc122d222fc1b47f929e7
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
