PA006__repair
Original source-BLEND procedural wood baked to embedded 1024px base-color and tangent-normal textures. Original UV0 retained, nonoverlapping UV1 added. Existing exact-zero cleanup retained where applicable. Material/UV repair, not a new base or color variant. Visual seam and source-appearance validation recorded separately.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-painter-atelier/PA006_CC0.zip
OriginalZIP SHA256 1a86947751c26e3f0b36d7a0176301fe525108f83b438888993252a4a9845e70
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
