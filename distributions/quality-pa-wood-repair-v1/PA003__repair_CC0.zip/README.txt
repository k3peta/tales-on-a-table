PA003__repair
Original source-BLEND procedural wood baked to embedded 1024px base-color and tangent-normal textures. Original UV0 retained, nonoverlapping UV1 added. Existing exact-zero cleanup retained where applicable. Material/UV repair, not a new base or color variant. Visual seam and source-appearance validation recorded separately.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-painter-atelier/PA003_CC0.zip
OriginalZIP SHA256 8492d400b37bb2a73b297952a1b105fdd5d54332f7a16c26fa6c799e4f030f7e
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
