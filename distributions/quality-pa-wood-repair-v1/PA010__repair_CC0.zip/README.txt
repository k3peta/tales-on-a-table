PA010__repair
Original source-BLEND procedural wood baked to embedded 1024px base-color and tangent-normal textures. Original UV0 retained, nonoverlapping UV1 added. Existing exact-zero cleanup retained where applicable. Material/UV repair, not a new base or color variant. Visual seam and source-appearance validation recorded separately.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-painter-atelier/PA010_CC0.zip
OriginalZIP SHA256 fe9ea69856164000c053f45e53043a4fafbd65b4bbf6b7389d424b8252174c9c
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
