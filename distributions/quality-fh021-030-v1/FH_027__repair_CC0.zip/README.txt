FH_027__repair
Type: revision of FH_027; not a new shape.
魚運び木箱の強い木目コントラストを抑え、板と把手の構造を明瞭化。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_027_CC0.zip
Source ZIP SHA256: e277bd313c42f74ab5f3ebcc7fe905bb8de6560a715c7415537c267702483a54
CC0 model and embedded materials only; private code, audit records and images excluded.
