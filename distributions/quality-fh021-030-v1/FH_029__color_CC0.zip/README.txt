FH_029__color
Type: material_variant of FH_029; not a new shape.
索の浮子のみ赤茶色に変更。索と結び目は維持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_029_CC0.zip
Source ZIP SHA256: 3c62e9c150147803eff91bd4304f07cedc7157cb9296bf971ce5d08fd6e13e36
CC0 model and embedded materials only; private code, audit records and images excluded.
