FH_028__repair
Type: revision of FH_028; not a new shape.
塩漬け桶の反復木目を抑制。錆びた箍と元形状は維持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_028_CC0.zip
Source ZIP SHA256: 7fe29ffa0c7042923dd82687d220d5e024889ac0879977248751cfdc7b31c099
CC0 model and embedded materials only; private code, audit records and images excluded.
