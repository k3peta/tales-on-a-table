FH_023__repair
Type: revision of FH_023; not a new shape.
網干し木枠の過度な反復木目を抑え、柱梁・接合部の視認性を改善。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_023_CC0.zip
Source ZIP SHA256: 73606864451c9f850e0d149a094a5edfae5e3d12cd3fe963a79e4d0966d6022d
CC0 model and embedded materials only; private code, audit records and images excluded.
