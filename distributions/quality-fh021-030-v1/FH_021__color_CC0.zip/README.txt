FH_021__color
Type: material_variant of FH_021; not a new shape.
帆布を淡い青灰色に変更。結び紐と折り畳み形状は維持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_021_CC0.zip
Source ZIP SHA256: 7efdbd111cccd1079ec37215a8ac14dced6111fb3a8bbaf58a980cf3ee4863de
CC0 model and embedded materials only; private code, audit records and images excluded.
