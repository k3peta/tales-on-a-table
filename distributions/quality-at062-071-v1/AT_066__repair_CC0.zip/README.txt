AT_066__repair
Type: revision of AT_066; not a new base shape.
Two floating gems lowered onto planar tray pad; topology/UV retained, geometry revision.
Two floating gem components translated vertically to the tray pad. Original topology and UV retained; bounds may change. Geometry revision, not a same-geometry variant. Lowest-vertex contact measured; physical stability and continuous collision untested.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_066_CC0.zip
Source ZIP SHA256: e6533387f21d2793ec5c11fcf2a91621fdf160dbfb185ddd8ea6547d40460c8f
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
