AT_071__color_green
Type: material_variant of AT_071; not a new base shape.
Pouch main leather changed to green; repair patch, stitches and cord retained.
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_071_CC0.zip
Source ZIP SHA256: 2a5cf3441e398e08122453ab6d48fb18bc95139648f084cceed8de9b36b68561
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
