AT_062__color_blue
Type: material_variant of AT_062; not a new base shape.
Weight display pad changed from green to blue; brass weights retained.
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_062_CC0.zip
Source ZIP SHA256: a7dbaa0cb52c7caa24e5e3840292ff02383fbeda7ceb989e58609d5b8b3415f0
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
