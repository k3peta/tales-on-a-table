NP104_WetOverhang
Structural variant: full sea bed-.19/water-.01 under roof underside.75/top1; N solid land1.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [2.0, 2.0, 1.9800000190734863]. Placement datum Z0, fixed bottom Z-.98. Normal river wet width1.2m. Water surfaces are thin static opaque planes, not volumetric water.
Blender 5.2.2 LTS and GLB round-trip checked. Terrain is stylized geometry. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
