NP103_DoubleMouth
Structural variant: N river into S full sea, central sand island makes two outlets.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [2.0, 2.0, 0.9876831485889852]. Placement datum Z0, fixed bottom Z-.98. Normal river wet width1.2m. Water surfaces are thin static opaque planes, not volumetric water.
Blender 5.2.2 LTS and GLB round-trip checked. Terrain is stylized geometry. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
