FW009__repair
Material repair of existing model; no new base shape or color variant.
Invalid albedo-as-normal connections removed. Albedo image bytes and original material parameters preserved; mesh normals used. Original geometry, transforms and UV retained. No replacement normal detail invented.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-forest-witch/FW009_CC0.zip
Original ZIP SHA256: 82ad4fc54eb0b32b58cd77790338fcdd0487d6fd78350e1814ab6c0c014d2323
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
