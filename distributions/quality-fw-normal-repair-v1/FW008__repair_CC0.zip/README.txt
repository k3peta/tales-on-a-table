FW008__repair
Material repair of existing model; no new base shape or color variant.
Invalid albedo-as-normal connections removed. Albedo image bytes and original material parameters preserved; mesh normals used. Original geometry, transforms and UV retained. No replacement normal detail invented.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-forest-witch/FW008_CC0.zip
Original ZIP SHA256: 4bddef0d18352465646171d1f151a12a429bcf9e8cbd978c53870c515e41a56a
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
