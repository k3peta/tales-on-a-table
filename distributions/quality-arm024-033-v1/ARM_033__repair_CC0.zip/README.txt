ARM_033__repair
Exact-zero-area cleanup with all positive surfaces and vertex colors retained: ARM026 23, ARM031 48, ARM033 64 faces. Budget remains exceeded. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_033_CC0.zip
OriginalZIP SHA256 56abf604529ec3403f475baa0c63ceba081ced92dada9494d4e423b233a88d72
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
