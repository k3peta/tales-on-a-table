ARM_026__repair
Exact-zero-area cleanup with all positive surfaces and vertex colors retained: ARM026 23, ARM031 48, ARM033 64 faces. Budget remains exceeded. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_026_CC0.zip
OriginalZIP SHA256 d24f881afb4e5d4361d00de1e5c7e7e9adf94901a94a5e4292ad6aa7a30e3767
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
