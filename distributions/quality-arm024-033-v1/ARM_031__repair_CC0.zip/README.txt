ARM_031__repair
Exact-zero-area cleanup with all positive surfaces and vertex colors retained: ARM026 23, ARM031 48, ARM033 64 faces. Budget remains exceeded. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_031_CC0.zip
OriginalZIP SHA256 1a50920f240829188fea5e5ecbb09b9f86bf4ca2b82f1e464e30a42c8d970a82
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
