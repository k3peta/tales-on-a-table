OL_004__color
Type: material_variant of OL_004; not a new shape.
カウンター前面のタイルだけ赤系へ変更。石天板・木部・金装飾は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_004_CC0.zip
Source ZIP SHA256: 96c6b4c301e5bf1ea3528aa3cc7b2a9ca8613fcd3c8aaff6642ad2c797aca268
CC0 model and embedded materials only; private code, audit records and images excluded.
