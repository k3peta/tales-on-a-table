FH_055__repair
Type: revision of FH_055; not a new shape.
仕掛け巻きの木目を抑え、糸と浮子・巻き枠を読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_055_CC0.zip
Source ZIP SHA256: 49b82e4381a0a386e172d485ddc4e539697f103718ab741710ef4a33743493aa
CC0 model and embedded materials only; private code, audit records and images excluded.
