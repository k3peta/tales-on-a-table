FH_053__repair
Type: revision of FH_053; not a new shape.
竿立ての過度な反復木目を抑え、支柱と受け部を明瞭化。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_053_CC0.zip
Source ZIP SHA256: d0d51432599940ca7d9b98505360cc942a84071dba194044652ca8c1282e4085
CC0 model and embedded materials only; private code, audit records and images excluded.
