FH_054__repair
Type: revision of FH_054; not a new shape.
餌箱の反復木目を抑え、仕切りと補修布の視認性を改善。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_054_CC0.zip
Source ZIP SHA256: 5dea5b759233fdbd0b14706f30613259f1ea8d1f03cf4754335402c644b76805
CC0 model and embedded materials only; private code, audit records and images excluded.
