OL_003__color
Type: material_variant of OL_003; not a new shape.
壺の本体を赤茶色の陶器調へ変更。金の帯・装飾・形状は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_003_CC0.zip
Source ZIP SHA256: 82c168059f63d6dde796c9e29a248997f544168a5b852c941ce660a41da33a28
CC0 model and embedded materials only; private code, audit records and images excluded.
