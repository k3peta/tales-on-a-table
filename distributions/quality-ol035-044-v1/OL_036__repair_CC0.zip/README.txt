OL_036__repair
Type: revision of OL_036; not a new shape.
長椅子木部の強い周期木目を抑制。金具と張地は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_036_CC0.zip
Source ZIP SHA256: d645388921c615936b20b721cc74f63f0feb5a4675ff7d912f55dc93cdf2e524
CC0 model and embedded materials only; private code, audit records and images excluded.
