OL_038__repair
Type: revision of OL_038; not a new shape.
壁飾り曲刀の刃の過剰な斑状模様を抑え、輪郭を読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_038_CC0.zip
Source ZIP SHA256: ec793713e2455b23379c4bb1954ba6745107cedacce03bfdb0e87ee897cd76b4
CC0 model and embedded materials only; private code, audit records and images excluded.
