OL_035__color
Type: material_variant of OL_035; not a new shape.
壁掛け絨毯の布面を落ち着いた緑色へ変更。房・装飾・形状を保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_035_CC0.zip
Source ZIP SHA256: 3ce18c3e0b26ba02fdc3fc09b16fa2313d2e389c90c3cf0be37a6cf4514ff1ad
CC0 model and embedded materials only; private code, audit records and images excluded.
