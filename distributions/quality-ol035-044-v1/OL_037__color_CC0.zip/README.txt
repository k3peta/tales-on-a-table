OL_037__color
Type: material_variant of OL_037; not a new shape.
硬貨を銀色へ変更。金属属性・刻印・積み方は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_037_CC0.zip
Source ZIP SHA256: 491126aa7922dcf960c5becc3d2f1cf17585299b77a561e8d011db805abafa15
CC0 model and embedded materials only; private code, audit records and images excluded.
