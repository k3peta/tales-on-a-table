BD202_Horsetail
Jointed stems with seven-way whorled branches. Damp forest edge or waterside bank. Origin is soil level.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.5257978141307831, 0.49837158620357513, 0.9004097529686987]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
