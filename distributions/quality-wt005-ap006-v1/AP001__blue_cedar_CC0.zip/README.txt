AP001__blue_cedar
Blue cedar recolor of existing UV woodgrain on repaired AP001 baseline, other material channels and shape retained. Not a new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-apiary/AP001_CC0.zip
OriginalZIP SHA256 3f691ef1cf18bd892ec84043dfaa1331fbcb0c82b63a4f75ad02fe0e04f432ca
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
