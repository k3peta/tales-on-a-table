WT005__repair
Remove exact-zero world-area faces only; preserve positive surfaces, materials and existing UV. Add missing UV where absent. WT007/008 use current v2 source, water geometry unchanged; bank material mosaic remains unresolved.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WT005_CC0.zip
OriginalZIP SHA256 ddfe65bfb7b08239db445c7b0d941e9d6f43c6acf199da87a7f08e36bca3f4bf
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
