AP005__repair
Remove exact-zero world-area faces only; preserve positive surfaces, materials and existing UV. Add missing UV where absent. WT007/008 use current v2 source, water geometry unchanged; bank material mosaic remains unresolved.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-apiary/AP005_CC0.zip
OriginalZIP SHA256 42b1f4fa1cd6d8770c327b0b77ff257d2606346cd0a627b3fd1765aa01312450
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
