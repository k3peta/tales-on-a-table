AP003__repair
Remove exact-zero world-area faces only; preserve positive surfaces, materials and existing UV. Add missing UV where absent. WT007/008 use current v2 source, water geometry unchanged; bank material mosaic remains unresolved.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-apiary/AP003_CC0.zip
OriginalZIP SHA256 2547d52969c7969c969edd5dab248b66a3ac2b06fe3babd4a7cc679d08495050
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
