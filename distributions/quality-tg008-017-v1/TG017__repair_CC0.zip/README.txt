TG017__repair
Distribution record TG017; contained model TG017. This is a single model revision of the existing record; no new design.
Geometry cleanup only: 12 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG017_CC0.zip
SourceZIP SHA256 5cf1a3840eed5d6e8c22a6e8b0cefd46c4311d49b8c459b5336efd72c68bf374
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
