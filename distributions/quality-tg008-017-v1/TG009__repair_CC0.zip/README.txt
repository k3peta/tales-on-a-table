TG009__repair
Distribution record TG009; contained model TG009. This is a single model revision of the existing record; no new design.
Geometry cleanup only: 4 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG009_CC0.zip
SourceZIP SHA256 91db2a574dad4876abd720af283ea62fbc4b5d887be1b3a807a275e22071f977
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
