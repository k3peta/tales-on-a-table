TG010__repair
Distribution record TG010; contained model TG010. This is a single model revision of the existing record; no new design.
Geometry cleanup only: 4 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG010_CC0.zip
SourceZIP SHA256 391e48845a34af7a190a409f807707e9cfdc3f7f7c57eaee5a363303a482c0c6
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
