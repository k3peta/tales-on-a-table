TG015__repair
Distribution record TG015; contained model TG015. This is a single model revision of the existing record; no new design.
Geometry cleanup only: 4 exact-zero-area faces removed. All positive surfaces, original material parameters and original absence of UV/color attributes preserved. No bake or new UV. Existing procedural-looking triangle material facets retained; not a full surface redesign. Existing model revision, not new base or variant.
Source https://raw.githubusercontent.com/k3peta/tales-on-a-table/main/distributions/terrain-connectivity-91/zips/TG015_CC0.zip
SourceZIP SHA256 7edf11f12bdb41ea919af676dc3a45b62fe142a8fc3443ea8bd3bbfee1d99d60
Blender5.2.2 tested, no gameplay/physics/4.3.2 guarantee. Model and embedded materials CC0 only; code/images/private handoff excluded.
