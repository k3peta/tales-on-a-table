OL_019__color
Type: material_variant of OL_019; not a new shape.
compact_pair_v1配置を保持した緑/赤茶のクッション一式。金ボタン・縫い糸は保持。
Cushions regrouped with 0.12m gap by rigid translation; variant matches compact_pair_v1 layout, not original arrangement. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_019_CC0.zip
Source ZIP SHA256: d8dbce1a94174ccdfa4dba29b62ce5f387edef2b62b742a494495f37c2cc2ad3
CC0 model and embedded materials only; private code, audit records and images excluded.
