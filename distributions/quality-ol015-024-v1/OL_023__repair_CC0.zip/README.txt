OL_023__repair
Type: revision of OL_023; not a new shape.
水差しの強い反復釉薬模様を抑え、口・胴・取っ手を読みやすくした材質改訂。
Original mesh geometry and transforms retained. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_023_CC0.zip
Source ZIP SHA256: 8f83a79512018cb14d36d7c2071dfcb95b70ad35853b3e7c29282dfe09b3855d
CC0 model and embedded materials only; private code, audit records and images excluded.
