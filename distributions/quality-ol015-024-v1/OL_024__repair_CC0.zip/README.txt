OL_024__repair
Type: revision of OL_024; not a new shape.
飾り壺の反復模様を弱め、金帯と口元の形を明瞭化した材質改訂。
Original mesh geometry and transforms retained. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_024_CC0.zip
Source ZIP SHA256: 8a776e18a0e02d2f61b952a7a70a95a13418eb61f2bf3433eb887333f2d983a8
CC0 model and embedded materials only; private code, audit records and images excluded.
