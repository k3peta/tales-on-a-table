RF02: Pasture gate fixed catch
Recovered existing model; no new geometry.
Units metres, Z up, origin zero. 2m bay/post pitch, not a 2m square tile.
Bounds: [[-0.10000000149011612, -0.10000000149011612, 0.7049999833106995], [-0.0690000057220459, -0.009999997913837433, 0.7950000166893005]]
Connectors: [{"mount_face_x": -0.08, "latch_slot_center": [-0.09, -0.055, 0.75], "clear_y": 0.036, "clear_z": 0.04}]
Classification: new component candidate
RF02 mounts at latch-side post origin and is intentionally above ground. RF07 static gate leaf starts above ground and needs separate posts.
BLEND: Append named Collection. Blender 5.2.2 LTS. BLEND/GLB round-trip checked. No gate animation, physics, walking, FPS or 4.3.2 compatibility validation.
RF03 is the flat original of published RS202 slope derivative; do not count as a newly designed shape. Corner/inline/end posts are structural variants. Existing assembly references include other models not included here.
