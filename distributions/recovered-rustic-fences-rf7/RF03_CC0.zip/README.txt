RF03: Low kitchen-garden round-stake bay
Recovered existing model; no new geometry.
Units metres, Z up, origin zero. 2m bay/post pitch, not a 2m square tile.
Bounds: [[-0.949999988079071, -0.061000000685453415, 0.0], [0.949999988079071, 0.03999999910593033, 0.6616247296333313]]
Connectors: [{"x": -0.95, "z": 0.18, "y": 0.015}, {"x": -0.95, "z": 0.45, "y": 0.015}, {"x": 0.95, "z": 0.18, "y": 0.015}, {"x": 0.95, "z": 0.45, "y": 0.015}]
Classification: new topology candidate
RF02 mounts at latch-side post origin and is intentionally above ground. RF07 static gate leaf starts above ground and needs separate posts.
BLEND: Append named Collection. Blender 5.2.2 LTS. BLEND/GLB round-trip checked. No gate animation, physics, walking, FPS or 4.3.2 compatibility validation.
RF03 is the flat original of published RS202 slope derivative; do not count as a newly designed shape. Corner/inline/end posts are structural variants. Existing assembly references include other models not included here.
