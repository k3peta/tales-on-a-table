RF06: Garden terminal post
Recovered existing model; no new geometry.
Units metres, Z up, origin zero. 2m bay/post pitch, not a 2m square tile.
Bounds: [[-0.061000000685453415, -0.05999999865889549, 0.0], [0.05999999865889549, 0.05999999865889549, 0.7300000190734863]]
Connectors: [{"x": 0.05, "y": 0.0, "z": 0.18}, {"x": 0.05, "y": 0.0, "z": 0.45}]
Classification: structural derivative
RF02 mounts at latch-side post origin and is intentionally above ground. RF07 static gate leaf starts above ground and needs separate posts.
BLEND: Append named Collection. Blender 5.2.2 LTS. BLEND/GLB round-trip checked. No gate animation, physics, walking, FPS or 4.3.2 compatibility validation.
RF03 is the flat original of published RS202 slope derivative; do not count as a newly designed shape. Corner/inline/end posts are structural variants. Existing assembly references include other models not included here.
