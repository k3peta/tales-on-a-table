RF07: Low garden gate with fixed hinge and catch hardware
Recovered existing model; no new geometry.
Units metres, Z up, origin zero. 2m bay/post pitch, not a 2m square tile.
Bounds: [[-0.949999988079071, -0.07000000029802322, 0.06999999284744263], [0.9500000476837158, 0.051874373108148575, 0.6499999761581421]]
Connectors: [{"post_pitch": 2, "post_faces": [-0.95, 0.95], "pin_axis_x": -0.915, "closed_leaf_bounds_x": [-0.88, 0.935], "hinge_z": [0.18, 0.45]}]
Classification: structural derivative
RF02 mounts at latch-side post origin and is intentionally above ground. RF07 static gate leaf starts above ground and needs separate posts.
BLEND: Append named Collection. Blender 5.2.2 LTS. BLEND/GLB round-trip checked. No gate animation, physics, walking, FPS or 4.3.2 compatibility validation.
RF03 is the flat original of published RS202 slope derivative; do not count as a newly designed shape. Corner/inline/end posts are structural variants. Existing assembly references include other models not included here.
