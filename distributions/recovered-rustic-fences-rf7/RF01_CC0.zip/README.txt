RF01: Pasture inline shared post
Recovered existing model; no new geometry.
Units metres, Z up, origin zero. 2m bay/post pitch, not a 2m square tile.
Bounds: [[-0.10000000149011612, -0.10000000149011612, 0.0], [0.10000000149011612, 0.10000000149011612, 1.2699999809265137]]
Connectors: [{"x": -0.08, "z": 0.35}, {"x": -0.08, "z": 0.7}, {"x": -0.08, "z": 1.05}, {"x": 0.08, "z": 0.35}, {"x": 0.08, "z": 0.7}, {"x": 0.08, "z": 1.05}]
Classification: structural derivative
RF02 mounts at latch-side post origin and is intentionally above ground. RF07 static gate leaf starts above ground and needs separate posts.
BLEND: Append named Collection. Blender 5.2.2 LTS. BLEND/GLB round-trip checked. No gate animation, physics, walking, FPS or 4.3.2 compatibility validation.
RF03 is the flat original of published RS202 slope derivative; do not count as a newly designed shape. Corner/inline/end posts are structural variants. Existing assembly references include other models not included here.
