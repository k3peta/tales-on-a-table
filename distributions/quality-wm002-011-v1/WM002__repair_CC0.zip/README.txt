WM002__repair
Remove 24 exact zero-world-area grain faces, retain every positive surface triangle and attributes; add missing timber-check UV.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM002_CC0.zip
OriginalZIP SHA256 155113faeda9fea0c9f29e41bbeae0638560574ca118a60f5558962e68b21221
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
