WM007__repair
Add missing UV0 only on source timber-check detail meshes. Original geometry/materials and existing UV layers retained. UV-only revision, no new base or palette variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM007_CC0.zip
OriginalZIP SHA256 ac3b5c2a7401478edc58158132e4316290935e43012d270284c0512313709cac
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
