WM006__repair
Add missing UV0 only on source timber-check detail meshes. Original geometry/materials and existing UV layers retained. UV-only revision, no new base or palette variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM006_CC0.zip
OriginalZIP SHA256 6b687d723ccf85df3daf35c92374fb2a3d8f6d242d9da17736f36bbd13410481
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
