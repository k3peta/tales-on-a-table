WM005__repair
Add missing UV0 only on source timber-check detail meshes. Original geometry/materials and existing UV layers retained. UV-only revision, no new base or palette variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM005_CC0.zip
OriginalZIP SHA256 be3930aeea29d59bcf60376e6b8ef60c134287a82fbb76188639db5db91c9d6a
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
