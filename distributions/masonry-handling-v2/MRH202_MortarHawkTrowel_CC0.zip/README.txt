MRH202_MortarHawkTrowel
composite_accessory
Metres/Z-up, model origin ground0 (carried props in upright rest pose; not freestanding safety equipment). Append Collection BLEND. Static artistic models. No load/safety, ergonomic shoulder fit, functional transport/plastering, collision or4.3.2 validation. Do not use as construction instructions. Geometry/materials CC0 only; code/render/private records excluded.
