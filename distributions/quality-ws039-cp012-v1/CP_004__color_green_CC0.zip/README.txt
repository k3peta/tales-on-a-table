CP_004__color_green
Green goatskin texture on CP004 cleaned geometry baseline; same positive surface and retained UV as repair. Original canvas and other material properties unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-captain-cabin/CP_004_CC0.zip
OriginalZIP SHA256 71a4a25e6547570f3dc509066acda04aa8cf738c79cbebdd8f844c0f34d7236a
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
