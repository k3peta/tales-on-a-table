CP_003__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-captain-cabin/CP_003_CC0.zip
OriginalZIP SHA256 8fdc1e4be2ff1e8e1c5ee793da6aa14732ccfc7632094dc2ea4824ed87e58006
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
