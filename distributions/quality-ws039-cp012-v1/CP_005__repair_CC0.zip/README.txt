CP_005__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-captain-cabin/CP_005_CC0.zip
OriginalZIP SHA256 d051bb2425f857e9318bd8da0f0e8986e6f74510578279b86a5bd0d584829433
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
