CP_010__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-captain-cabin/CP_010_CC0.zip
OriginalZIP SHA256 d0339648c2ea3d3a214b911257fc09c5086ef9dcda21133b0fcfc1468ab67700
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
