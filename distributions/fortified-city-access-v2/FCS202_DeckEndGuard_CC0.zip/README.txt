FCS202_DeckEndGuard
structural_accessory
Metres/Z-up. Append the Collection from BLEND. Static models, no collision/walking/structural-safety verification. Blender5.2.2;4.3.2 compatibility untested.
FCS201 floorZ2, W/S central1m mouths; guard rails outside2m deck. FCS202 origin is attachment floor; placeZ2 at existing bay endX1. Gate105 access v2 replaces rear guard with1m opening; not another independent asset. GateAccess example reuses four ER101 rise1 stair modules over16m run; unused lateral ports closed with scene guards and elevated steps supported.
