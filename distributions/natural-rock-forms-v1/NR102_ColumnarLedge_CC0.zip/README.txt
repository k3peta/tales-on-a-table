NR102_ColumnarLedge
2x1m grounded columnar rock cluster. Polygonal vertical fracture faces with chipped/dished caps. Common baseZ0..0.1. Intended exposed rock dressing; top silhouette does not form a sealed terrain-tile port.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [2.0, 1.0, 1.2654210329055786]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Rock forms are stylized numeric surfaces; not geological or structural validation. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
