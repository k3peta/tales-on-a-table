NR101_FlowstoneApron
2m wide rock apron. Toe y-.8 at Z0, back y.5 topZ1.6. Matching E/W profile for 2m pitch. Longitudinal folds on curved solid surface. Cave dressing, not a walkable ramp.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [2.0, 1.300000011920929, 1.600000023841858]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Rock forms are stylized numeric surfaces; not geological or structural validation. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
