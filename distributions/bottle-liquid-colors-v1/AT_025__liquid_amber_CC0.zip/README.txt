AT_025__liquid_amber
Geometry-preserving LIQUID MATERIAL VARIANT of AT_025. Colour: amber. Not a new base shape.
Only existing inner liquid material region changed; glass exterior, label, stopper, geometry and UV retained. No emission. Fictional potion bottle styling remains; not relabelled as a drink. Static model, no liquid simulation. Blender5.2.2 neutral and warm dim lighting tested; other renderer transparency and Blender4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_025_CC0.zip
Source ZIP SHA256: b76c29c3c1a5d798bd8bfc74da1af55526adad5cb234e79e1c1dfaa706eb6c65
CC0 model and embedded materials only. Private code and records excluded.
