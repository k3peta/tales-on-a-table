CP_025__green_silk
Green silk texture mapped to CP025 wine silk material only, using cleaned geometry and explicitly added missing UV baseline. Other material properties unchanged.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-captain-cabin/CP_025_CC0.zip
OriginalZIP SHA256 d0ce187c1cce72e6ee57b60634965ca93a423c24184bceb5a5aeedbf94c3b7a0
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
