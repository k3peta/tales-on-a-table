IF_002__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-independent-furnishings/IF_002_CC0.zip
OriginalZIP SHA256 483196bfa56eb96c65d3f3fee3d10885eb19fd8708df4a4f24bed95ea8a18a43
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
