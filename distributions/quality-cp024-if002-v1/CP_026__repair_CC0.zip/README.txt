CP_026__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-captain-cabin/CP_026_CC0.zip
OriginalZIP SHA256 d9c97bb96edabfa748d803d4cd418566299a8b18c9a3d12e134d018e52eae65a
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
