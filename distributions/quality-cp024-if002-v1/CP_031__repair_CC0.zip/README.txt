CP_031__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-captain-cabin/CP_031_CC0.zip
OriginalZIP SHA256 1ca719ddab7b94ed565c4d66a7eac11a0f8218c5e6d2fcc5fe6eefd53079907e
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
