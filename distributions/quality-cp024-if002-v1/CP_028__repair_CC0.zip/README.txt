CP_028__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-captain-cabin/CP_028_CC0.zip
OriginalZIP SHA256 5ddcee7188e96c9cad09fd90172633d3a677e79c3a0ad3f939fa52d1cc039224
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
