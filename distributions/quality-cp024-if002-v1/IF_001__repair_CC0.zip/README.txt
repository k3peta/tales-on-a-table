IF_001__repair
Exact-zero-area cleanup only, all positive surfaces retained; missing UV added where recorded in revision notes. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-independent-furnishings/IF_001_CC0.zip
OriginalZIP SHA256 a099714c4cfd39bc81e29d2fcf5f69113ac2df801cbedd51b86df2f6592eae6c
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
