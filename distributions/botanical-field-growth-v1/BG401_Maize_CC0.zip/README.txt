BG401_Maize
Tall stalk with long blade leaves, lateral husked ears and terminal branched tassel.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.8913065791130066, 0.9033590257167816, 1.6803475618362427]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
