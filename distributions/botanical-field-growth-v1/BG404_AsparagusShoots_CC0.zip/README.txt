BG404_AsparagusShoots
Seven emerging tapering spears with small overlapping tip scales; spring shoot stage, not mature fern foliage.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.32797206938266754, 0.3232327401638031, 0.5400854349136353]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
