BG402_Eggplant
Branching vegetable shrub with broad leaves and hanging elongated purple fruit under green calyx.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [0.8137220144271851, 0.7338312864303589, 0.7502787709236145]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
