BG403_Artichoke
Deeply cut basal leaves and three stalked heads built from overlapping pointed bracts.
Unit metres, Z up, root origin (0,0,0). Size XYZ: [1.0518845319747925, 1.0397658348083496, 1.0732293128967285]. Ground/float datum documented in the use description; small stem cross-sections can extend slightly below the datum.
Blender 5.2.2 LTS and GLB round-trip checked. Leaves are stylized thin surfaces. Static: no wind, rig, collision, or walking validation; 4.3.2 compatibility untested. Global historical uniqueness unconfirmed.
BLEND is a model collection library; append its named collection.
