AT_034__color_orange
Type: material_variant of AT_034; not a new base shape.
材質改修した帽子の橙色variant。形状UV保持。
Geometry/UV retained for color variants; AT034 uses repaired normal/roughness material baseline. AT038 is a separate stitch geometry repair with topology/UV retained. No new emission, glass or liquid changes.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_034_CC0.zip
Source ZIP SHA256: 09901917ca629678093510b47bcc911ff7f4a657b1bdfca1cd0efcc4c2aa6db7
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
