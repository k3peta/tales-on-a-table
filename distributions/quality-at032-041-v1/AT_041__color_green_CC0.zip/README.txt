AT_041__color_green
Type: material_variant of AT_041; not a new base shape.
陶器の釉薬色を緑へ。ひびと補修留め具は保持。
Geometry/UV retained for color variants; AT034 uses repaired normal/roughness material baseline. AT038 is a separate stitch geometry repair with topology/UV retained. No new emission, glass or liquid changes.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_041_CC0.zip
Source ZIP SHA256: 25bef25d74ca8f2b3047da1b2270c671b29a8b55106af83d9684a7d9ab746ca6
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
