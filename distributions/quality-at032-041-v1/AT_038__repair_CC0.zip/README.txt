AT_038__repair
Type: revision of AT_038; not a new base shape.
前面8本の縫い目を+Y 3mm動かし革へ接地。形状改訂、元トポロジーUV保持。
Geometry/UV retained for color variants; AT034 uses repaired normal/roughness material baseline. AT038 is a separate stitch geometry repair with topology/UV retained. No new emission, glass or liquid changes.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_038_CC0.zip
Source ZIP SHA256: 19b0200df94631dc2a5f39f0fb4035e9d99bd43a62b6d2c2746cee1c187486e0
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
