AT_033__color_blue
Type: material_variant of AT_033; not a new base shape.
鞄の革を青へ。木製フラップ・金具・継ぎ当て保持。
Geometry/UV retained for color variants; AT034 uses repaired normal/roughness material baseline. AT038 is a separate stitch geometry repair with topology/UV retained. No new emission, glass or liquid changes.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_033_CC0.zip
Source ZIP SHA256: fe9025a51eb2c2e2594a551eeb693a645696fa1896ffd1440b77073257f6de3c
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
