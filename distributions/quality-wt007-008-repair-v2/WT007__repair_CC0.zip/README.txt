WT007__repair
Type: revision of WT007; not a new base shape.
Trim water solid to existing channel banks, removing coplanar overlapping black wedges at tile ends. Water level -0.01 m and 2 m tile preserved; outlet water width 1.188421 m matches both revised tiles.
Trim water solid to existing channel banks, removing coplanar overlapping black wedges at tile ends. Water level -0.01 m and 2 m tile preserved; outlet water width 1.188421 m matches both revised tiles. Geometry repair, not a material variant or new shape.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WT007_CC0.zip
Source ZIP SHA256: 1a8541449e9f4f6162edcc06b73288847fd7dbef01a1bc73ed96d6a3f13a0341
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
