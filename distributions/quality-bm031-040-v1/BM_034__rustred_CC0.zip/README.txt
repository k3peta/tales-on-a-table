BM_034__rustred
Rust-red UV tint on cushion main moss fabric. Original geometry, UV, vertex colors, patches/cords and non-basecolor channels unchanged. Not a mesh repair or new shape; polygon budget remains exceeded.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_034_CC0.zip
OriginalZIP SHA256 b2961ff878bb0b380263c074b70c4d4050248787b474d9cb0fb42ac77375215c
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
