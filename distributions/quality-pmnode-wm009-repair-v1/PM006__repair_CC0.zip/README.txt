PM006__repair
Type: revision of PM006; not a new base shape.
Coincident mortar/stone side faces removed by recessing mortar core 10mm; original stone surfaces and materials retained.
Coincident mortar/stone side faces removed by recessing mortar core 10mm; original stone surfaces and materials retained. Geometry repair, not a material variant or new shape.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.20-prison/PM006_Universal_Stone_Node.zip
Source ZIP SHA256: 1670d97953c5e776d4d1fcc9576e95d887fb8ca3e12f599b54f0abfb3ff4425f
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
