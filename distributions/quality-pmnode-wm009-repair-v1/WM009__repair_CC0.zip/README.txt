WM009__repair
Type: revision of WM009; not a new base shape.
Added rear heel wall following original scoop section to connect existing floating handle; source meshes retained.
Added rear heel wall following original scoop section to connect existing floating handle; source meshes retained. Geometry repair, not a material variant or new shape.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-watermill/WM009_CC0.zip
Source ZIP SHA256: f5bc61b636641f68411c79c7bd83caf2f964e2997618d24ae2fa2811414c2f7e
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
