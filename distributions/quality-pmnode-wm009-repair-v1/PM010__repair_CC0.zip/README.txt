PM010__repair
Type: revision of PM010; not a new base shape.
Coincident mortar/stone side faces removed by recessing mortar core 10mm; original stone surfaces and materials retained.
Coincident mortar/stone side faces removed by recessing mortar core 10mm; original stone surfaces and materials retained. Geometry repair, not a material variant or new shape.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.20-prison/PM010_T_Junction_Configuration.zip
Source ZIP SHA256: f39123a70c2f2769bed925e67a5f5047159149adb559cc3bbf5d1e97c5fd3bd7
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
