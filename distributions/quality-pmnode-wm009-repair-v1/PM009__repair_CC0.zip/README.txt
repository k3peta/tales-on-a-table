PM009__repair
Type: revision of PM009; not a new base shape.
Coincident mortar/stone side faces removed by recessing mortar core 10mm; original stone surfaces and materials retained.
Coincident mortar/stone side faces removed by recessing mortar core 10mm; original stone surfaces and materials retained. Geometry repair, not a material variant or new shape.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.20-prison/PM009_L_Corner_Configuration.zip
Source ZIP SHA256: c642db0810ba3817266ebce90acf37b77535dfce1ea30b4c82e7efee58612b04
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
