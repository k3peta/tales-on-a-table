PM011__repair
Type: revision of PM011; not a new base shape.
Coincident mortar/stone side faces removed by recessing mortar core 10mm; original stone surfaces and materials retained.
Coincident mortar/stone side faces removed by recessing mortar core 10mm; original stone surfaces and materials retained. Geometry repair, not a material variant or new shape.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.20-prison/PM011_End_Cap_Configuration.zip
Source ZIP SHA256: d58f368149418c8eb63bc36547a10819373d210c20989e8c23a36fe071cc78bb
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
