INF101_CanvasStretcher
Static canvas stretcher with carrying handles and resting legs. Not a certified medical device.
Metres, Z-up in Blender. Append Collection BLEND; scene furnishings remain repositionable. Bounds: [[-0.4000000059604645, -1.25, 0.0], [0.4000000059604645, 1.25, 0.4650000035762787]]
Static art: no structural safety, active mechanisms, collision/real walking, historical accuracy or4.3.2 compatibility validation. Model geometry and embedded materials CC0 only; code/images/private records excluded.
