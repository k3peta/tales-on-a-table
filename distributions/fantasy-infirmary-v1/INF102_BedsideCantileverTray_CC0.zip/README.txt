INF102_BedsideCantileverTray
Bedside cantilever tray with outside support foot; topZ1.05m.
Metres, Z-up in Blender. Append Collection BLEND; scene furnishings remain repositionable. Bounds: [[-0.30000001192092896, -0.4000000059604645, 0.0], [1.2000000476837158, 0.4000000059604645, 1.1200000047683716]]
Static art: no structural safety, active mechanisms, collision/real walking, historical accuracy or4.3.2 compatibility validation. Model geometry and embedded materials CC0 only; code/images/private records excluded.
