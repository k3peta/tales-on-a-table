INFV01_FantasyInfirmary
Fictional infirmary assembly, existing berths/screens/linen/basin/medicine box/bench/candle. Static scene only, no medical procedures or efficacy claims.
Metres, Z-up in Blender. Append Collection BLEND; scene furnishings remain repositionable. Bounds: [[-3.5, -4.5, 0.0], [3.5, 4.050000190734863, 2.940000057220459]]
Static art: no structural safety, active mechanisms, collision/real walking, historical accuracy or4.3.2 compatibility validation. Model geometry and embedded materials CC0 only; code/images/private records excluded.
