OL_028__color
Type: material_variant of OL_028; not a new shape.
扁球形ランプの金属枠を銅色へ変更。ガラス・発光・暗色鎖は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_028_CC0.zip
Source ZIP SHA256: a2f8ebae6430a99fca07dcee2754a9241f3866dd4e95c9d3a661ef41ff7b97dd
CC0 model and embedded materials only; private code, audit records and images excluded.
