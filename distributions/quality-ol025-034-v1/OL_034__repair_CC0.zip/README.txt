OL_034__repair
Type: revision of OL_034; not a new shape.
商人の櫃の周期木目を抑え、蓋・金帯・錠前を読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_034_CC0.zip
Source ZIP SHA256: 36a3fa7d1cb5701a0dec77686421c8fa94bac3e2924066338021b9b5ff9fdf36
CC0 model and embedded materials only; private code, audit records and images excluded.
