OL_033__repair
Type: revision of OL_033; not a new shape.
宝石箱の蓋の強い周期模様を抑え、宝石と縁取りを読みやすくした材質改訂。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_033_CC0.zip
Source ZIP SHA256: 5bab279200b23d2b831a391107f3f936de514927312e7e9e0a93cfcf1809ad0a
CC0 model and embedded materials only; private code, audit records and images excluded.
