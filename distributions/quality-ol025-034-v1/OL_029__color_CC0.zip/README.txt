OL_029__color
Type: material_variant of OL_029; not a new shape.
装飾用水煙草器の上部陶器だけ赤茶色へ変更。ガラス胴・金属・ホースは保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_029_CC0.zip
Source ZIP SHA256: 0799cdf6f538d137134b334241de76adf462071e49e7d10c27bc81eaa3c78725
CC0 model and embedded materials only; private code, audit records and images excluded.
