OL_014__color
Type: material_variant of OL_014; not a new shape.
巻いた絨毯を緑と赤茶の組へ変更。結び紐・巻き形状は保持。
Original mesh geometry and transforms retained. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_014_CC0.zip
Source ZIP SHA256: c6366d2a15511a44833c3f3116adcc715b79558acbe07d1f92c3b898ffbaed94
CC0 model and embedded materials only; private code, audit records and images excluded.
