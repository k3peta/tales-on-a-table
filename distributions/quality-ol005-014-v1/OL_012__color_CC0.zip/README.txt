OL_012__color
Type: material_variant of OL_012; not a new shape.
展示トレイと指輪金属を銀色へ変更。宝石色と形状は保持。
Original mesh geometry and transforms retained. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_012_CC0.zip
Source ZIP SHA256: 354ca96aff4f5a17605cfa2e8b5e0564955e0ea4051a16382ef872806cc365a8
CC0 model and embedded materials only; private code, audit records and images excluded.
