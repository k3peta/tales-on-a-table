OL_011__repair
Type: revision of OL_011; not a new shape.
細長い敷物の四隅の同高重複を除去した形状改訂。
Transverse border ends trimmed to remove coplanar corner overlap; variant geometry matches border_trim_v1 revision, not old original. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_011_CC0.zip
Source ZIP SHA256: 6a9393b0c46220e1218ad527ea46aa932406fbab5b288f17db65faa842afbbd5
CC0 model and embedded materials only; private code, audit records and images excluded.
