OL_013__repair
Type: revision of OL_013; not a new shape.
サイドテーブルの強い周期木目を抑え、金飾りと八角形の輪郭を明瞭化。
Original mesh geometry and transforms retained. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_013_CC0.zip
Source ZIP SHA256: b79a872377bc64100bcff3d73e52a653c89d28da234e90ddb3c246f997273297
CC0 model and embedded materials only; private code, audit records and images excluded.
