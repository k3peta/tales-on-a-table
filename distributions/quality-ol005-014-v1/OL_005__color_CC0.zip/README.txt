OL_005__color
Type: material_variant of OL_005; not a new shape.
修整後border_trim_v1形状を保持した緑系の絨毯。房と菱形模様は保持。
Transverse border ends trimmed to remove coplanar corner overlap; variant geometry matches border_trim_v1 revision, not old original. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_005_CC0.zip
Source ZIP SHA256: d92d9efc2b43c96d99ed226ea62d63316c503d026ec28adf299c5140015950e4
CC0 model and embedded materials only; private code, audit records and images excluded.
