OL_011__color
Type: material_variant of OL_011; not a new shape.
修整後border_trim_v1形状を保持した赤茶系の敷物。房と模様は保持。
Transverse border ends trimmed to remove coplanar corner overlap; variant geometry matches border_trim_v1 revision, not old original. original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/OL_011_CC0.zip
Source ZIP SHA256: 6a9393b0c46220e1218ad527ea46aa932406fbab5b288f17db65faa842afbbd5
CC0 model and embedded materials only; private code, audit records and images excluded.
