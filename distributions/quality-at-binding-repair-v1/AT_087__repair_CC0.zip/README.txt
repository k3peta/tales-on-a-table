AT_087__repair
Geometry repair of existing model; no new base shape or color variant.
Binding cords replaced with closed tubes around paper or textile section envelopes; detached knot replaced with attached loop. Binding topology and UV changed. Other model coordinates retained except documented whole-model ground translation. Taut spans bridge concavities; not cloth simulation or a functional knot.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_087_CC0.zip
Original ZIP SHA256: 80a01a16e06057bccb3f7f0c50b55edfc9ee62b2cf5484fd3e77e8b978e0f27e
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
