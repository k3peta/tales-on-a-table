AT_082__repair
Geometry repair of existing model; no new base shape or color variant.
Binding cords replaced with closed tubes around paper or textile section envelopes; detached knot replaced with attached loop. Binding topology and UV changed. Other model coordinates retained except documented whole-model ground translation. Taut spans bridge concavities; not cloth simulation or a functional knot.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_082_CC0.zip
Original ZIP SHA256: e1e13203e959e99bb5f5279a876bfd33906642cc8f94b70fc6029fe7cbf7edab
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
