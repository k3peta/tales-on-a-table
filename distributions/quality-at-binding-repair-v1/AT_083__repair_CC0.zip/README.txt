AT_083__repair
Geometry repair of existing model; no new base shape or color variant.
Binding cords replaced with closed tubes around paper or textile section envelopes; detached knot replaced with attached loop. Binding topology and UV changed. Other model coordinates retained except documented whole-model ground translation. Taut spans bridge concavities; not cloth simulation or a functional knot.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_083_CC0.zip
Original ZIP SHA256: d5575fe57061f88fbd6bd5cc8876334926431f6651f2c63958dc1968a744f2e4
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
