AT_086__repair
Geometry repair of existing model; no new base shape or color variant.
Binding cords replaced with closed tubes around paper or textile section envelopes; detached knot replaced with attached loop. Binding topology and UV changed. Other model coordinates retained except documented whole-model ground translation. Taut spans bridge concavities; not cloth simulation or a functional knot.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_086_CC0.zip
Original ZIP SHA256: 5de5c3d7d88d629247522c1c1b2a6a21f68359bee3be247396fef24ce9291725
Models and embedded materials CC0 only. Code, private handoff and images excluded. Blender5.2.2 tested;4.3.2/gameplay/collision untested.
