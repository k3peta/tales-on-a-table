RG101_OpenTreeGuard
Open-top/open-bottom eight-sided tree guard. Origin at soilZ0, stakes to1.32m, central cylinder radius.5m unobstructed. Outer radius under.70m. Four fixed straps at two seams, no animation. Place trees independently; trees and soil not included.
Metres, Z up, origin zero. Blender5.2.2 LTS. Append named Collection. Bounds [[-0.6825000047683716, -0.6474999785423279, 0.0], [0.6825000047683716, 0.6474999785423279, 1.3200000524520874]]
Static miniature. No water dynamics, mechanisms, game collision, actual walking or Blender4.3.2 compatibility tested. Sampled geometry tests only. Overlapping solids, not manifold union. Global historical shape independence unconfirmed.
