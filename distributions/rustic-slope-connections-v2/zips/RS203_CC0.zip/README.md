# RS203 - Fence crossing stile

Freestanding miniature stile: double-sided treads at 0.3, 0.6, 0.9 and 1.2 m, narrow deck over the existing pasture rail. Decorative/static use only; no human safety, structural loading, animal containment or actual walking certification.

Metres, Z up, root origin zero. Models and included packed display materials only: CC0-1.0. Code, images, assembled examples and private handoff are not included. Blender 5.2.2 reimport tested; 4.3.2 compatibility, game collision and full contact/structural safety remain untested.

Slope examples require terrain contact support under the high post: a 0.02 m local support is shown separately, not included as a new model. Ground contact is not solved for arbitrary terrain. Post/fence originals are separate existing assets.
