# RS202 - Garden slope bay

2 m horizontal post pitch, 0.5 m rise. Rail ends x=+-0.95 fit RF05 at ground levels 0 and 0.5. Upright stakes follow sloped ground. Adapted from RF03.

Metres, Z up, root origin zero. Models and included packed display materials only: CC0-1.0. Code, images, assembled examples and private handoff are not included. Blender 5.2.2 reimport tested; 4.3.2 compatibility, game collision and full contact/structural safety remain untested.

Slope examples require terrain contact support under the high post: a 0.02 m local support is shown separately, not included as a new model. Ground contact is not solved for arbitrary terrain. Post/fence originals are separate existing assets.
