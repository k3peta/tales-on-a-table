FH_009__color
Type: material_variant of FH_009; not a new shape.
岸壁敷石の暖かい砂色。目地と形状は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_009_CC0.zip
Source ZIP SHA256: 07f225e78a4f9ff53aa7bce6a012e34c2c2f620d236b6df333641d72c71a6d0e
CC0 model and embedded materials only; private code, audit records and images excluded.
