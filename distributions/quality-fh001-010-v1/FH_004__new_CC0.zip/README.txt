FH_004__new
Type: material_variant of FH_004; not a new shape.
ブイを赤とクリーム色で塗り直した材質。低ポリ輪郭は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_004_CC0.zip
Source ZIP SHA256: a901d18a5c212074aad7adc90ebd4aaa567ac97222191f07a4a29fe1875ffa86
CC0 model and embedded materials only; private code, audit records and images excluded.
