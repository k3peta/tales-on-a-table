FH_002__new
Type: material_variant of FH_002; not a new shape.
錨の酸化材質を手入れされた鉄色へ。形状・木部・ロープは保持。
Original mesh geometry and transforms retained; UV0 supplied on 15 formerly unwrapped constant-color meshes; existing UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FH_002_CC0.zip
Source ZIP SHA256: 8fb8e965c5b047bf42cb0e43e9bcdd43898c8fb76a059fb42ab8b5ef5277b658
CC0 model and embedded materials only; private code, audit records and images excluded.
