ARM_034__navylinen
UV tint on original vertex colors: blue quilted linen or copper-colored shoulder-armor coating. Geometry/UV/roughness/metallic/normal/emission unchanged. Not a new model or geometry repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_034_CC0.zip
OriginalZIP SHA256 7cd8b1fd45d602a3676ac42e9403dd3e5bb0a406ccd95d796b880e9d41951dc5
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
