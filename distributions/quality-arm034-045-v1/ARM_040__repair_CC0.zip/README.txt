ARM_040__repair
Exact-zero-area cleanup with original positive surfaces, UV and vertex colors retained: ARM040 144 faces, ARM045 120 faces. Budget warning remains. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_040_CC0.zip
OriginalZIP SHA256 5f17137761ee1ce2bc28a2e197ff39a0628195719db4524eeb08bced8e885117
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
