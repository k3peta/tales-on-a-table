ARM_045__repair
Exact-zero-area cleanup with original positive surfaces, UV and vertex colors retained: ARM040 144 faces, ARM045 120 faces. Budget warning remains. No new base.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-armory/ARM_045_CC0.zip
OriginalZIP SHA256 779678103c3792db5162d36e23b30183f8ed32d2420d944cc6168ae05b94b9f0
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
