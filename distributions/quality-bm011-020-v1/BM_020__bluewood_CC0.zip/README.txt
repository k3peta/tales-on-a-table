BM_020__bluewood
Blue UV tint on walnut board surfaces of shallow parts tray; lighter frame, iron and all non-basecolor channels unchanged. Original mesh, UV and vertex colors preserved. Same base model, not new shape.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-bridge-market/BM_020_CC0.zip
OriginalZIP SHA256 1e1c6f238d9cdd9e3fad2022b713ab3440f45831e2669d3f5912dea59270fbce
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
