WS_021__repair
WS021 revision:99 exact-zero-area faces removed; positive faces and UV retained. Embedded basecolor PNG losslessly recompressed with identical filtered pixels, resolution/offset metadata removed. Broad byte-marker scan unchanged and passed. No new model or material variant.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.19-wizard-study/WS_021_CC0.zip
OriginalZIP SHA256 e381438156b4b5dbc02de1773b404f79b0c93aaf095a08a5b45c8639b0ffcff8
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
