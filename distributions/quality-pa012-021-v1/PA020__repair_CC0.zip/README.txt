PA020__repair
Original source-BLEND procedural materials (wood, paper, linen, plaster or iron as applicable) baked to embedded 1024px base-color and tangent-normal textures. Original UV0 retained, nonoverlapping UV1 added. 496 exact-zero faces removed across five affected assets; positive surfaces retained. Material/UV repair, not a new base or color variant. Visual seam and source-appearance validation recorded separately.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-painter-atelier/PA020_CC0.zip
OriginalZIP SHA256 86b437d895679be7e061140b75be125af066f631162666ff718c877dd326af92
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
