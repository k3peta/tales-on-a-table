# Terrain batch 9 — coastal connections
Model-only distribution candidate. Not published.
Geometry, UVs and included display materials: CC0-1.0 within distributor rights. Code, input references, article, scene and example images are excluded from this license and from this ZIP.
2 m modular miniatures, metres, XY-centred origin. See MODEL-INDEX.json for individual bounds and water level. Blender 5.2.2. Game walking/collisions, arbitrary combinations and Blender 4.3.2 compatibility are not certified. This record count is not a global independent-design count.

Asset: UB901 / beach_shore_transition
