IN017__blue_ceramic
UV color variant with unchanged baseline geometry/UV; alpha, roughness and other materials preserved. No new base model or wear simulation.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-inn/IN017_CC0.zip
OriginalZIP SHA256 a6cb502bbad2c0f9ad67cd1aa9424c066712b899e8228c724dc9c22034e87786
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
