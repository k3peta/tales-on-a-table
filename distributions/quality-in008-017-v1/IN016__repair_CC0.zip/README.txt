IN016__repair
Remove exact-zero world-area faces only; preserve all positive surfaces/materials/UV/colors. No new base model. Known limitation: inner-wall protrusion-like feature near handle remains undiagnosed; this revision only removes exact-zero faces, not a full visual repair.
Source https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.21-inn/IN016_CC0.zip
OriginalZIP SHA256 e3766bbcda1334330bc906ae6ff924123efe100856936dc7bddadd379847510e
Blender5.2.2 tested. No collision/gameplay/4.3.2 compatibility guarantee.
CC0 model and embedded materials only. Images and private code/handoff excluded.
