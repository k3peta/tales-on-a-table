HCV601: Paired static donkey cart shaft adapters
Units: metres; Z up. Ground-centered origin. Dimensions XYZ: [1.03000009059906, 1.3240001201629639, 0.30986487865448].
BLEND is an object library: File > Append > Object > HCV601.
GLB can be imported normally. All required model data are embedded. No external textures.
Fine procedural bump is Blender-only. GLB retains base colors, roughness and geometry.
Static decorative model for vignettes, not a mechanically functional or safety-rated structure. No animation, animal simulation, collision or fluid behavior is provided. Not a standard terrain-port connector. Resize and position for your arrangement.
Tested with Blender 5.2.2 LTS: both formats reload, finite bounds, ground origin, no zero-area faces and no missing material slots. Older Blender versions, other viewers and application FPS are untested.
Only geometry and included materials are CC0-1.0. See LICENSE-CC0.txt.

Matched decorative assembly: BM_048 donkey at (2.8,0,0), rotated Z +90 degrees; reused HCV506 cart restored to raw coordinates plus Z +0.005 m. This part placement: [2.200000047683716, 5.960464477539063e-08, 0.7821351289749146]. Coupling centers (2.65, -0.59, 1.02) and (2.65, +0.59, 1.02) metres. Not a physically simulated hitch.
