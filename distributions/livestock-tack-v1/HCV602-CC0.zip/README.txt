HCV602: Matched saddle attachment straps and shaft loops
Units: metres; Z up. Ground-centered origin. Dimensions XYZ: [0.12299036979675293, 1.3539999723434448, 0.4942464828491211].
BLEND is an object library: File > Append > Object > HCV602.
GLB can be imported normally. All required model data are embedded. No external textures.
Fine procedural bump is Blender-only. GLB retains base colors, roughness and geometry.
Static decorative model for vignettes, not a mechanically functional or safety-rated structure. No animation, animal simulation, collision or fluid behavior is provided. Not a standard terrain-port connector. Resize and position for your arrangement.
Tested with Blender 5.2.2 LTS: both formats reload, finite bounds, ground origin, no zero-area faces and no missing material slots. Older Blender versions, other viewers and application FPS are untested.
Only geometry and included materials are CC0-1.0. See LICENSE-CC0.txt.

Matched decorative assembly: BM_048 donkey at (2.8,0,0), rotated Z +90 degrees; reused HCV506 cart restored to raw coordinates plus Z +0.005 m. This part placement: [2.633504867553711, 0.0, 0.9329999685287476]. Coupling centers (2.65, -0.59, 1.02) and (2.65, +0.59, 1.02) metres. Not a physically simulated hitch.
