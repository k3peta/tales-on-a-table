AT_042__repair
Type: revision of AT_042; not a new base shape.
Exterior brass ornament faces subdivided and seated along outer cup wall; removes cavity intrusion. Original dimensions preserved; geometry revision, not variant.
Exterior brass ornament faces subdivided and seated along outer cup wall; removes cavity intrusion. Original dimensions preserved; geometry revision, not variant. Geometry repair, not a material variant or new shape.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_042_CC0.zip
Source ZIP SHA256: bb2980f0feb0be36d2d9df10c9f568825b2bc4c50768a26c895c35bf9ab64587
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
