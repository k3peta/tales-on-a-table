AT_073__color_blue
Type: material_variant of AT_073; not a new base shape.
Green lid lining changed to blue; all other materials and geometry/UV retained.
Original geometry, transforms and UV0 retained. Base color texture mapped via existing UV; no new emission, no glass or liquid modification.
Static decorative asset. No functional mechanism, collision or strength guarantee. Blender 5.2.2 tested; 4.3.2 untested.
Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/AT_073_CC0.zip
Source ZIP SHA256: 7493ba2a0b712d5c39fb370c0cd1af1d118ec84876a0806f55f24e31c6d78cfb
CC0 models and embedded materials only. Private scripts, audit records and images excluded.
