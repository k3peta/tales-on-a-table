MRT101_PlumbLevel
local_use_candidate
Metres/Z-up, model origin ground0 except wall-mounted MRT106 whose X0 is wall plane and Z0 is base. Append Collection BLEND. Static artistic models. No actual surveying accuracy, load/safety, functional lifting, gate operation, fire operation, collision or4.3.2 validation. Do not use as construction instructions. Geometry/materials CC0 only; code/render/private records excluded.
