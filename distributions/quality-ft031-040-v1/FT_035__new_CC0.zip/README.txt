FT_035__new
Type: material_variant of FT_035; not a new shape.
Maintained frame with restrained wood grain; paper and cork unchanged.
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_035_CC0.zip
Source ZIP SHA256: 21b7760c7b8eeac7bc9065d98dc88f58bfcd0b5e756e9fb032669d74d9ecb483
CC0 model and embedded materials only; private code, audit records and images excluded.
