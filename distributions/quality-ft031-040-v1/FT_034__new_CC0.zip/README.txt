FT_034__new
Type: material_variant of FT_034; not a new shape.
Maintained target finish with restrained wood grain; sector pattern retained.
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_034_CC0.zip
Source ZIP SHA256: 8978e5018abe13ec93deac8745e42dca98c3d4d6e0681261fbf6f8bdc4772479
CC0 model and embedded materials only; private code, audit records and images excluded.
