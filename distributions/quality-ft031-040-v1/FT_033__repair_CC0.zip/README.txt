FT_033__repair
Type: revision of FT_033; not a new shape.
Quality revision: raise iron albedo to reveal tool silhouettes; preserve metallic factor and geometry.
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_033_CC0.zip
Source ZIP SHA256: 8ec096cdfc525d4219b9d33b9af7c8daf813977f2ceeb10cada5950b99cf1b2c
CC0 model and embedded materials only; private code, audit records and images excluded.
