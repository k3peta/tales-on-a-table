FT_040__color
Type: material_variant of FT_040; not a new shape.
Oxblood satchel using repaired body/flap UVs; linen unchanged.
Original mesh geometry and transforms retained; missing UV0 supplied on body and flap; existing UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_040_CC0.zip
Source ZIP SHA256: bb635241a992e983c6f6e7cbadafec47974a2f461ff7a27d56c9b4f267e37620
CC0 model and embedded materials only; private code, audit records and images excluded.
