FT_037__new
Type: material_variant of FT_037; not a new shape.
Maintained signboards with restrained wood grain.
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_037_CC0.zip
Source ZIP SHA256: e6d76610fda08bf732a2dc3eb264e35ab9ef9466caafcd8a7d3ec7b3037f9acb
CC0 model and embedded materials only; private code, audit records and images excluded.
