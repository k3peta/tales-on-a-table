FT_038__color
Type: material_variant of FT_038; not a new shape.
Oxblood leather pouch; cord unchanged.
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_038_CC0.zip
Source ZIP SHA256: 780d81937518e27ccafc31398e1ea73a7a12b691d5c65d529abe91cd97aaf11e
CC0 model and embedded materials only; private code, audit records and images excluded.
