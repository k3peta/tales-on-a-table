FT_031__color
Type: material_variant of FT_031; not a new shape.
Cool grey stone alternative.
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_031_CC0.zip
Source ZIP SHA256: e9888487f6c541bfcdd741cd469cfe8ef8d0885bf341f55e4a4383c2e406fb1c
CC0 model and embedded materials only; private code, audit records and images excluded.
