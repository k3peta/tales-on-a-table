FT_036__new
Type: material_variant of FT_036; not a new shape.
Maintained wooden A-frame; slate and geometry unchanged.
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_036_CC0.zip
Source ZIP SHA256: 533e87b4cc833554eba3203a23927d14acc2b3c9b33afb9588aef52f428fb09e
CC0 model and embedded materials only; private code, audit records and images excluded.
