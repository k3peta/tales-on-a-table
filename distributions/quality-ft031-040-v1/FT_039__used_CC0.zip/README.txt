FT_039__used
Type: material_variant of FT_039; not a new shape.
Subtle cup-foot patina and restrained wooden dice grain; pip recesses unchanged.
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_039_CC0.zip
Source ZIP SHA256: 5720d42e539272f9a85c2e8655ff04325f53b42fce7d8d5c4f33e83c21bd9e43
CC0 model and embedded materials only; private code, audit records and images excluded.
