FT_046__color
Type: material_variant of FT_046; not a new shape.
石床の青灰色材質。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_046_CC0.zip
Source ZIP SHA256: c273fdb71fd5141a9d9da00f54b516f8c35207d77a884beb38d0e82a972679ba
CC0 model and embedded materials only; private code, audit records and images excluded.
