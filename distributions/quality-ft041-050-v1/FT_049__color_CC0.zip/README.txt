FT_049__color
Type: material_variant of FT_049; not a new shape.
ラグの落ち着いた青色。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_049_CC0.zip
Source ZIP SHA256: 2a2fc62f714e925fa3a7ec9dffcb5a11d620af88a468d946fcd9ec102974d643
CC0 model and embedded materials only; private code, audit records and images excluded.
