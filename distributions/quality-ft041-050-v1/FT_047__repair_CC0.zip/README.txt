FT_047__repair
Type: revision of FT_047; not a new shape.
木目を抑制し、段鼻の白い反射帯をcoat/specularの抑制で修正した艶消し木階段。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_047_CC0.zip
Source ZIP SHA256: 3874d355354eddf7328b3640f8011cb4b98be6538a7ca8b2ed241d76c110c86c
CC0 model and embedded materials only; private code, audit records and images excluded.
