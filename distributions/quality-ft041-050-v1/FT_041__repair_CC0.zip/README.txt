FT_041__repair
Type: revision of FT_041; not a new shape.
粗い木目の黒斑を抑え、扉と枠の構造を読み取りやすくした材質改修。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_041_CC0.zip
Source ZIP SHA256: 8d738149479f2f28db093ace553feb7d1d2b0edaccf176080cbcf77045e310f0
CC0 model and embedded materials only; private code, audit records and images excluded.
