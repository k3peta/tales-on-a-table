FT_050__color
Type: material_variant of FT_050; not a new shape.
木枠を保持しリネンを淡い青色へ変更。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_050_CC0.zip
Source ZIP SHA256: e1b791e8d010a492160ad4eb5fdf6c5cabe3fda3e9b79b580124d3d28f28c643
CC0 model and embedded materials only; private code, audit records and images excluded.
