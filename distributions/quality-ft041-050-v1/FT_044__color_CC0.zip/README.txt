FT_044__color
Type: material_variant of FT_044; not a new shape.
漆喰部分だけを淡い暖色に変更。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_044_CC0.zip
Source ZIP SHA256: 60a8bf956f64498523747b9d396253f73706613c5bfc879f97f9aada738be38c
CC0 model and embedded materials only; private code, audit records and images excluded.
