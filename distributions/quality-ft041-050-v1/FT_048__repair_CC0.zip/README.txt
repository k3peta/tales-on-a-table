FT_048__repair
Type: revision of FT_048; not a new shape.
手すりの粗木目を抑制し支柱の輪郭を明瞭化。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_048_CC0.zip
Source ZIP SHA256: 7064d0d7fe57aefbec7cb15f67ba407fcbb2d0e5a435151f39bc3289f3037d3a
CC0 model and embedded materials only; private code, audit records and images excluded.
