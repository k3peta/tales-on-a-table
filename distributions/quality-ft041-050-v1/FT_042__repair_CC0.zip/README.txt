FT_042__repair
Type: revision of FT_042; not a new shape.
窓枠の粗い木目を抑制。ガラスの透過条件は保持。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_042_CC0.zip
Source ZIP SHA256: 662bb063ad45ef401f0fa9fd6dbcd72db03d20a17f86a4ae53350abdceff6bab
CC0 model and embedded materials only; private code, audit records and images excluded.
