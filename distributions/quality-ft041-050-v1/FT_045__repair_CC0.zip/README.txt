FT_045__repair
Type: revision of FT_045; not a new shape.
板床の黒い斑を抑え板の境界を明瞭化。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_045_CC0.zip
Source ZIP SHA256: 48dd1cf144f11cb44cdbc1955b98bdf8592d3f7a72044545ad04d6c5e950b97b
CC0 model and embedded materials only; private code, audit records and images excluded.
