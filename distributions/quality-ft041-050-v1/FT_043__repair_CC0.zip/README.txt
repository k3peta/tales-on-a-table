FT_043__repair
Type: revision of FT_043; not a new shape.
柱梁の過度に強い木目を抑制。
Original mesh geometry and transforms retained; original UV0 retained. WearUV is added to textured objects. Static decorative model, no combustion/mechanical safety or game collision guarantee. Blender 5.2.2 tested, 4.3.2 untested. Source: https://github.com/k3peta/tales-on-a-table/releases/download/v2026.10.18/FT_043_CC0.zip
Source ZIP SHA256: 220521c9f55cba9c500f0c3f43881c63eede2f2d4c33004a8a2b26d8f521ed91
CC0 model and embedded materials only; private code, audit records and images excluded.
